"""
accept_s45_s47.py — Two-pass XML accept for S45–S47 tracked changes
Proven method from S39–S44 session:
  Pass 1: Unwrap <w:ins>content</w:ins> (keep content, remove tags)
  Pass 2: Strip remaining orphaned <w:ins ...> opening tags (self-closing pPr trackers)
Also strips: w:del blocks, w:rPrChange, w:pPrChange
"""
import zipfile, re, shutil, os

SRC = '/home/sandbox/monolith_project_summary_v25_accepted.docx'
BAK = '/home/sandbox/monolith_project_summary_v25_accepted_pre_accept_s47_backup.docx'

shutil.copy(SRC, BAK)
print(f'Backup: {BAK}')

with zipfile.ZipFile(SRC, 'r') as z:
    xml = z.read('word/document.xml').decode('utf-8')
    all_files = {name: z.read(name) for name in z.namelist()}

before_ins = len(re.findall(r'<w:ins[ >]', xml))
print(f'w:ins before accept: {before_ins}')

# -- Strip w:del blocks (tracked deletions — remove entirely)
xml = re.sub(r'<w:del\b[^>]*>.*?</w:del>', '', xml, flags=re.DOTALL)

# -- Strip w:rPrChange and w:pPrChange (formatting change markers)
xml = re.sub(r'<w:rPrChange\b[^>]*>.*?</w:rPrChange>', '', xml, flags=re.DOTALL)
xml = re.sub(r'<w:pPrChange\b[^>]*>.*?</w:pPrChange>', '', xml, flags=re.DOTALL)

# -- Pass 1: Unwrap <w:ins>content</w:ins> keeping inner content
xml = re.sub(r'<w:ins\b[^>]*>(.*?)</w:ins>', r'\1', xml, flags=re.DOTALL)

mid_ins = len(re.findall(r'<w:ins[ >]', xml))
mid_close = len(re.findall(r'</w:ins>', xml))
print(f'After pass 1 unwrap: {mid_ins} w:ins opening tags, {mid_close} closing tags')

# -- Pass 2: Strip all remaining orphaned <w:ins ...> opening tags
# (self-closing <w:ins w:id="..."/> inside <w:pPr><w:rPr> — spot-check: w:ins[ >] not w:insideH/V)
xml = re.sub(r'<w:ins\b[^>]*/>', '', xml)   # self-closing
xml = re.sub(r'<w:ins\b[^>]*>', '', xml)    # any remaining opening tags

after_ins = len(re.findall(r'<w:ins[ >]', xml))
after_close = len(re.findall(r'</w:ins>', xml))
print(f'After pass 2 strip: {after_ins} w:ins, {after_close} </w:ins>')

# -- Spot-check: ensure we didn't touch w:insideH or w:insideV
inside_h = xml.count('<w:insideH')
inside_v = xml.count('<w:insideV')
print(f'w:insideH intact: {inside_h}, w:insideV intact: {inside_v}')

# -- Write output
all_files['word/document.xml'] = xml.encode('utf-8')
with zipfile.ZipFile(SRC, 'w', compression=zipfile.ZIP_DEFLATED) as zout:
    for name, data in all_files.items():
        zout.writestr(name, data)

size = os.path.getsize(SRC)
print(f'\nFile size: {size:,} bytes')

# -- Content verification
with zipfile.ZipFile(SRC, 'r') as z:
    vxml = z.read('word/document.xml').decode('utf-8')
    for sec, keyword in [('S45','AMD-004 WS-B'),('S46','AMD-004 WS-C'),('S47','KPI-M4')]:
        print(f'{sec} present: {keyword in vxml}')
    final_ins = len(re.findall(r'<w:ins[ >]', vxml))
    print(f'Final w:ins count: {final_ins}')
    if final_ins == 0:
        print('✅ CLEAN ACCEPT COMPLETE')
    else:
        print(f'⚠️  {final_ins} w:ins remaining')
