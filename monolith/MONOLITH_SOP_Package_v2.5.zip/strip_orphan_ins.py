import zipfile, re, shutil, os

src = "/home/sandbox/monolith_project_summary_v25_accepted.docx"
with zipfile.ZipFile(src,"r") as z:
    names = z.namelist()
    files = {n: z.read(n) for n in names}

xml = files["word/document.xml"].decode("utf-8")
before = len(re.findall(r'<w:ins[ >]', xml))
print(f"Orphaned w:ins before: {before}")

# Strip all orphaned <w:ins ...> opening tags (no </w:ins> exists)
xml = re.sub(r'<w:ins\b[^>]*>', '', xml)

after = len(re.findall(r'<w:ins[ >]', xml))
print(f"w:ins after strip: {after}")
# Also verify no closing tags introduced
closing = len(re.findall(r'</w:ins>', xml))
print(f"</w:ins> closing tags: {closing}")

files["word/document.xml"] = xml.encode("utf-8")
tmp = src + ".tmp"
with zipfile.ZipFile(tmp,"w",zipfile.ZIP_DEFLATED) as zout:
    for n in names:
        zout.writestr(n, files[n])
os.replace(tmp, src)
print(f"File size: {os.path.getsize(src):,} bytes")

# Quick section check
for i in range(39,45):
    if f"{i}." in xml:
        print(f"  S{i}: ✓")
print("CLEAN ACCEPT COMPLETE")
