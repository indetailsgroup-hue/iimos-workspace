"""
inject_s45_s47.py
Inject Sections S45–S47 into monolith_project_summary_v25_accepted.docx
S45: AMD-004 WS-B Technology Infrastructure Next Generation + GAP-05 AI Creative Engine
S46: AMD-004 WS-C Client Service Innovation Delivery + GAP-06 Cross-Pillar Event Bus
S47: Real-time KPI Dashboard (GAP-08) — Phase 1 Roadmap Completion
"""
import zipfile, re, shutil, os

SRC = '/home/sandbox/monolith_project_summary_v25_accepted.docx'
DST = '/home/sandbox/monolith_project_summary_v25_accepted.docx'
BAK = '/home/sandbox/monolith_project_summary_v25_accepted_pre_s45_backup.docx'

shutil.copy(SRC, BAK)
print(f'Backup: {BAK}')

with zipfile.ZipFile(SRC, 'r') as z:
    xml = z.read('word/document.xml').decode('utf-8')
    all_files = {name: z.read(name) for name in z.namelist()}

# Force IDs to start at 673 (continuing from S39–S44 session)
_id = 673

def nid():
    global _id
    v = _id
    _id += 1
    return v

AUTHOR = "Scispace Agent"
DATE   = "2026-09-03T00:00:00Z"

def heading1(text):
    pi, ri = nid(), nid()
    return (
        f'<w:p><w:pPr><w:spacing w:before="320" w:after="100"/>'
        f'<w:rPr><w:ins w:id="{pi}" w:author="{AUTHOR}" w:date="{DATE}"/></w:rPr></w:pPr>'
        f'<w:ins w:id="{ri}" w:author="{AUTHOR}" w:date="{DATE}">'
        f'<w:r><w:rPr><w:b/><w:bCs/><w:sz w:val="36"/><w:szCs w:val="36"/>'
        f'<w:color w:val="1f2d5a"/></w:rPr>'
        f'<w:t xml:space="preserve">{text}</w:t></w:r></w:ins></w:p>\n'
    )

def heading2(text):
    pi, ri = nid(), nid()
    return (
        f'<w:p><w:pPr><w:spacing w:before="200" w:after="80"/>'
        f'<w:rPr><w:ins w:id="{pi}" w:author="{AUTHOR}" w:date="{DATE}"/></w:rPr></w:pPr>'
        f'<w:ins w:id="{ri}" w:author="{AUTHOR}" w:date="{DATE}">'
        f'<w:r><w:rPr><w:b/><w:bCs/><w:sz w:val="28"/><w:szCs w:val="28"/>'
        f'<w:color w:val="2e75b6"/></w:rPr>'
        f'<w:t xml:space="preserve">{text}</w:t></w:r></w:ins></w:p>\n'
    )

def body(text, indent=400):
    pi, ri = nid(), nid()
    return (
        f'<w:p><w:pPr><w:spacing w:before="0" w:after="80"/>'
        f'<w:ind w:left="{indent}"/>'
        f'<w:rPr><w:ins w:id="{pi}" w:author="{AUTHOR}" w:date="{DATE}"/></w:rPr></w:pPr>'
        f'<w:ins w:id="{ri}" w:author="{AUTHOR}" w:date="{DATE}">'
        f'<w:r><w:rPr><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>'
        f'<w:t xml:space="preserve">{text}</w:t></w:r></w:ins></w:p>\n'
    )

def bullet(text):
    pi, ri = nid(), nid()
    return (
        f'<w:p><w:pPr><w:spacing w:before="0" w:after="60"/>'
        f'<w:ind w:left="600" w:hanging="200"/>'
        f'<w:rPr><w:ins w:id="{pi}" w:author="{AUTHOR}" w:date="{DATE}"/></w:rPr></w:pPr>'
        f'<w:ins w:id="{ri}" w:author="{AUTHOR}" w:date="{DATE}">'
        f'<w:r><w:rPr><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr>'
        f'<w:t xml:space="preserve">• {text}</w:t></w:r></w:ins></w:p>\n'
    )

def label_value(label, value):
    pi, r1, r2 = nid(), nid(), nid()
    return (
        f'<w:p><w:pPr><w:spacing w:before="0" w:after="60"/>'
        f'<w:ind w:left="600"/>'
        f'<w:rPr><w:ins w:id="{pi}" w:author="{AUTHOR}" w:date="{DATE}"/></w:rPr></w:pPr>'
        f'<w:ins w:id="{r1}" w:author="{AUTHOR}" w:date="{DATE}">'
        f'<w:r><w:rPr><w:b/><w:bCs/><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr>'
        f'<w:t xml:space="preserve">{label}:  </w:t></w:r></w:ins>'
        f'<w:ins w:id="{r2}" w:author="{AUTHOR}" w:date="{DATE}">'
        f'<w:r><w:rPr><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr>'
        f'<w:t xml:space="preserve">{value}</w:t></w:r></w:ins></w:p>\n'
    )

# ============================================================
# SECTION 45 — AMD-004 WS-B: Technology Infrastructure Next Generation + GAP-05
# ============================================================
S45 = ""
S45 += heading1("45. AMD-004 WS-B — Technology Infrastructure Next Generation (GAP-05: AI Creative Engine)")
S45 += heading2("45.1  Workstream Overview")
S45 += body(
    "Section 45 defines the AMD-004 Workstream B (WS-B) implementation specification for Technology Infrastructure "
    "Next Generation. WS-B is the technical foundation workstream within the AMD-004 programme (฿5.2M, FY2031–FY2033) "
    "responsible for cloud infrastructure modernisation, API gateway consolidation, and the deployment of AI-powered "
    "creative tooling. Critically, this section closes GAP-05 (AI Creative Engine) — identified in the SOP-GitHub "
    "Coverage Analysis as a HIGH-priority missing module with no corresponding implementation in monolith-workspace. "
    "WS-B is the parent workstream for all infrastructure-dependent capabilities in Phase 2 of the Gap Resolution Roadmap."
)
S45 += body(
    "Budget Allocation: ฿1.1M (AMD-004 WS-B). Timeline: Q1–Q3 2031 (Phase 2 Roadmap). "
    "Responsible SC Decision: SC-2030-01 (authorises AMD-004 programme start). "
    "SLA Group Assignments: Group C agents (Atlas, Bo, Forge, Leo, Ops, Stone, Pulse, Frame) — ≥94% SLA threshold."
)

S45 += heading2("45.2  Technology Infrastructure Objectives")
S45 += body(
    "WS-B targets four infrastructure modernisation layers that underpin all Phase 2 and Phase 3 gap-resolution modules:"
)
S45 += label_value("Cloud Infrastructure (INFRA-WS-B-01)", "Migrate monolith-workspace compute from on-premise VM to managed Kubernetes cluster (GKE or AKS). "
    "Target: 99.9% uptime SLA, auto-scaling 28-agent pod deployment, zero-downtime rolling updates. "
    "Dependencies: src/core/supabase/ (data persistence layer), src/core/telemetry/ (observability).")
S45 += label_value("API Gateway Consolidation (INFRA-WS-B-02)", "Unify disparate REST/gRPC endpoints across src/agents/ into a single Kong or AWS API Gateway. "
    "Enforce JWT authentication, rate limiting (100 req/s per agent), and request tracing. "
    "Enables Cross-Pillar Event Bus (GAP-06, S46) to route inter-agent events reliably.")
S45 += label_value("Data Pipeline Modernisation (INFRA-WS-B-03)", "Upgrade src/data-pipeline/ to Apache Kafka event streaming with schema registry. "
    "Implement CDC (Change Data Capture) for real-time Supabase → Analytics sync. "
    "Provides the data substrate for Real-time KPI Dashboard (GAP-08, S47).")
S45 += label_value("Security & Compliance Layer (INFRA-WS-B-04)", "Deploy Zero-Trust network policy (mTLS between pods), Vault-managed secrets rotation, "
    "SOC2-Type-II audit logging. PDPA/GDPR data residency enforcement at infrastructure level. "
    "Prerequisite for PDPA Consent workflow (GAP-10) and Contractor Portal (GAP-11).")

S45 += heading2("45.3  GAP-05 AI Creative Engine — Module Specification")
S45 += body(
    "The AI Creative Engine (GAP-05) is a HIGH-priority missing module closing the absence of generative AI tooling "
    "for interior design creative production in DAPH Decor projects. The engine integrates large multimodal models "
    "with the existing Aria (Design Automation) and Blaze (Visual Intelligence) agents to deliver AI-assisted "
    "concept generation, material curation, and spatial visualisation — elevating DAPH Decor to World-Class "
    "AI-augmented design delivery standard."
)
S45 += body(
    "Target repository path: src/creative-engine/ (new module). Integration points: "
    "src/agents/aria/, src/agents/blaze/, src/agents/nova/, src/design-vault/ (material library)."
)
S45 += label_value("AIE-001 Concept Generation API", "REST endpoint POST /creative/concept — accepts project brief JSON (client profile, style references, "
    "budget tier, pillar selections) → returns 3–5 design concept directions with mood board imagery (DALL-E 3 / "
    "Stable Diffusion XL backend), design narrative text, and WELL/LEED compatibility score per concept.")
S45 += label_value("AIE-002 Material & Texture Synthesis", "REST endpoint POST /creative/material — given existing FF&E spec (furniture-hardware-vault entries) "
    "generates complementary texture options, colour palette expansions, and biophilic material suggestions. "
    "Output validated against Red List (GAP-01/S39.2 Material Transparency). Agents: Nova, Aria.")
S45 += label_value("AIE-003 Spatial Planning Assist", "Integration with src/bim/ (BIM module S20) — AI overlay on floor plan data to generate "
    "alternative furniture arrangement proposals ranked by spatial efficiency, flow score, and client preference model. "
    "Uses occupancy simulation heuristics from POE historical data (GAP-04/S42).")
S45 += label_value("AIE-004 Client Brief Interpreter", "NLP pipeline (GPT-4o) — parses unstructured client brief documents into structured design parameters "
    "(style vectors, budget constraints, timeline, special requirements). Output feeds directly into Design Brief "
    "Module (S3) and Design Freeze Gate checklist (GAP-02/S40).")
S45 += label_value("AIE-005 Creative Iteration Engine", "Version-controlled creative workflow: each concept iteration logged with delta-tracking, "
    "client approval status, and revision rationale. Integrates with Design Freeze Gate (S40.3 DFG-WS-01) "
    "to prevent unauthorised design changes post-freeze.")

S45 += heading2("45.4  Implementation Architecture")
S45 += body("The AI Creative Engine operates across a 3-tier deployment model within the WS-B infrastructure:")
S45 += bullet("Tier 1 — AI Inference Layer: Managed model endpoints (Azure OpenAI / GCP Vertex AI). "
    "Latency target: ≤3s for concept generation, ≤1s for material synthesis. Auto-scaled GPU pods.")
S45 += bullet("Tier 2 — Orchestration Layer: LangChain orchestration within Aria agent pod. "
    "Manages prompt engineering, context injection (project brief + design vault data), and output validation pipeline.")
S45 += bullet("Tier 3 — Integration Layer: Supabase persistence for creative artefacts, "
    "webhook triggers to notify Scout (Project Tracking) and Compass (Coordination) on concept approvals. "
    "Client-facing output delivered via encrypted share links through Shore (Client Relations) agent.")

S45 += heading2("45.5  Delivery Checklist (TECH-WS-B-01–06)")
S45 += label_value("TECH-WS-B-01", "Cloud infrastructure migration to Kubernetes — Forge agent lead, Atlas monitoring. Target: Q1 2031.")
S45 += label_value("TECH-WS-B-02", "API Gateway consolidation (Kong) deployed, all 28 agent endpoints registered. Target: Q1 2031.")
S45 += label_value("TECH-WS-B-03", "Kafka data pipeline deployed; CDC sync Supabase → Analytics verified end-to-end. Target: Q2 2031.")
S45 += label_value("TECH-WS-B-04", "AI Creative Engine src/creative-engine/ v1.0 — AIE-001 through AIE-005 all endpoints tested. Target: Q2 2031.")
S45 += label_value("TECH-WS-B-05", "Security layer: mTLS policy, Vault secrets, SOC2 logging — audit trail active across all pods. Target: Q2 2031.")
S45 += label_value("TECH-WS-B-06", "WS-B User Acceptance Testing: Aria + Blaze + Nova creative workflow E2E test on 3 live projects. Target: Q3 2031.")

S45 += heading2("45.6  Governance, Dependencies & Agent Assignments")
S45 += body(
    "WS-B is governed under SC Decision SC-2030-01 (AMD-004 programme authorisation). "
    "Programme Director: Core agent (Group D, ≥97% SLA). Infrastructure Lead: Forge (Group C, ≥94%). "
    "AI Engine Lead: Aria (Group A, ≥95%). Security Lead: Rex (Group D, ≥97%)."
)
S45 += body(
    "Dependencies: S38 (AMD-004 PDD — master programme budget ฿5.2M), S44 (GitHub Integration Roadmap — "
    "Kubernetes migration prerequisite), S40 (Design Freeze Gate — AIE-005 integration), "
    "S42 (POE Framework — AIE-003 occupancy data), S20 (BIM — AIE-003 floor plan data)."
)

S45 += heading2("45.7  Milestones (WS-B-M1–M4)")
S45 += label_value("WS-B-M1 (Q1 2031)", "Infrastructure migration complete — Kubernetes cluster live, API Gateway deployed, monitoring active.")
S45 += label_value("WS-B-M2 (Q2 2031)", "AI Creative Engine v1.0 deployed — AIE-001 to AIE-005 endpoints operational in staging.")
S45 += label_value("WS-B-M3 (Q2 2031)", "Security & compliance layer certified — SOC2 audit complete, Zero-Trust policy enforced.")
S45 += label_value("WS-B-M4 (Q3 2031)", "WS-B UAT passed — 3 live project E2E creative workflow validated, GAP-05 formally closed.")

# ============================================================
# SECTION 46 — AMD-004 WS-C: Client Service Innovation + GAP-06 Cross-Pillar Event Bus
# ============================================================
S46 = ""
S46 += heading1("46. AMD-004 WS-C — Client Service Innovation Delivery (GAP-06: Cross-Pillar Event Bus)")
S46 += heading2("46.1  Workstream Overview")
S46 += body(
    "Section 46 defines the AMD-004 Workstream C (WS-C) implementation specification for Client Service Innovation "
    "Delivery. WS-C is the client-facing innovation workstream within the AMD-004 programme, responsible for "
    "elevating the DAPH Decor client experience through real-time collaboration tools, personalised service delivery, "
    "and seamless cross-pillar project orchestration. This section simultaneously closes GAP-06 (Cross-Pillar Event Bus) "
    "— a HIGH-priority missing integration module identified in the SOP-GitHub Coverage Analysis. "
    "The Cross-Pillar Event Bus is the foundational architectural component that enables real-time state synchronisation "
    "across all six design pillars and 28 AI agents."
)
S46 += body(
    "Budget Allocation: ฿1.2M (AMD-004 WS-C — largest workstream by value due to client experience complexity). "
    "Timeline: Q2–Q4 2031 (Phase 2 Roadmap). SC Decision: SC-2030-01. "
    "Primary Agents: Kelly (SLA Group A, ≥95%), Shore (Group B, ≥93%), Compass (Group B, ≥93%), Signal (Group A, ≥95%)."
)

S46 += heading2("46.2  Client Service Innovation Objectives")
S46 += body(
    "WS-C targets four client experience innovation areas, each supported by existing or new monolith-workspace modules:"
)
S46 += label_value("Real-time Client Collaboration Portal (SVC-WS-C-01)", "Web-based secure portal (src/client-portal/ — new module) giving clients live project status, "
    "design concept previews, approval workflows, and direct messaging with project team agents. "
    "Integrates with Shore (Client Relations), Signal (Communications), and Remy (Reporting) agents.")
S46 += label_value("Personalised Service Engine (SVC-WS-C-02)", "Client preference model built from historical project data (src/data-pipeline/ + analytics). "
    "Proactively recommends design directions, material options, and schedule adjustments. "
    "Feeds AI Creative Engine (GAP-05/S45.3 AIE-004 Client Brief Interpreter).")
S46 += label_value("Digital Twin Client Preview (SVC-WS-C-03)", "VR/AR-ready 3D room preview generated from BIM data (S20) + AI texturing (AIE-002). "
    "Client-accessible via web-based 3D viewer (Three.js) without specialist hardware requirement. "
    "Preview versions locked at Design Freeze Gate (GAP-02/S40.3 DFG-WS-01) to prevent post-freeze scope creep.")
S46 += label_value("Post-Project Client Intelligence (SVC-WS-C-04)", "Automated post-completion satisfaction survey (Scout agent) feeding into POE database (GAP-04/S42). "
    "NPS scoring, WELL/LEED satisfaction tracking, referral probability scoring. "
    "Quarterly client portfolio health reports via Remy (Reporting) agent.")

S46 += heading2("46.3  GAP-06 Cross-Pillar Event Bus — Architecture Specification")
S46 += body(
    "The Cross-Pillar Event Bus (GAP-06) resolves the critical absence of a unified event-driven communication "
    "layer between the six design pillars (Conceptual Design, Spatial Planning, Material Selection, "
    "Technical Documentation, Procurement & Delivery, Commissioning & Handover). "
    "Without this bus, agents in different pillars operate in siloed HTTP polling loops, causing "
    "latency, missed state transitions, and manual handover errors between pillar stages."
)
S46 += body(
    "Target repository path: src/event-bus/ (new module). Technology: Apache Kafka (provisioned in WS-B/S45.2 "
    "INFRA-WS-B-03) with dedicated topics per pillar pair. All 28 agents subscribe as consumers; "
    "pillar-lead agents (Kelly, Compass, Aria, Atlas, Draft, Signal) also act as topic producers."
)
S46 += label_value("EVT-001 Pillar State Change Events", "Standardised CloudEvents schema (v1.0) for design state transitions: "
    "CONCEPT_APPROVED, SPATIAL_LOCKED, MATERIAL_SPECIFIED, TECH_DOC_ISSUED, PO_RAISED, COMMISSIONING_STARTED, "
    "HANDOVER_COMPLETE. Each event carries: project_id, pillar_id, agent_id, timestamp, payload_json, sla_deadline.")
S46 += label_value("EVT-002 Cross-Pillar Trigger Rules", "Rule engine (Drools / custom Python evaluator in src/event-bus/rules/) — "
    "defines conditional triggers: e.g., MATERIAL_SPECIFIED → auto-notify Procurement (Finn agent); "
    "CONCEPT_APPROVED + SPATIAL_LOCKED → trigger Design Freeze Gate evaluation (S40.3 DFG-WS-01); "
    "COMMISSIONING_STARTED → activate Sensory Commissioning Protocol (GAP-03/S41).")
S46 += label_value("EVT-003 Dead Letter Queue & Replay", "Failed event handling: DLQ with 3-retry policy + exponential backoff. "
    "Event replay capability (replay from timestamp) for project timeline reconstruction and "
    "audit trail generation (SC governance reports via Nexus agent).")
S46 += label_value("EVT-004 Real-time Dashboard Integration", "Event stream → WebSocket bridge → Real-time KPI Dashboard (GAP-08/S47). "
    "Pillar transition velocity KPIs: avg time per pillar stage, bottleneck identification, "
    "SLA breach prediction (Pulse agent alerts at 80% SLA consumption).")
S46 += label_value("EVT-005 Agent Coordination Protocol", "Standardised agent-to-agent handover packets via event bus. "
    "Replaces current direct HTTP calls between agent pods — improves resilience and enables "
    "async processing for non-blocking workflows (critical for 28-agent parallel execution).")

S46 += heading2("46.4  Implementation Architecture")
S46 += body("The Cross-Pillar Event Bus integrates three operational layers:")
S46 += bullet("Producer Layer: Pillar-lead agents emit structured events to dedicated Kafka topics "
    "(topic naming: monolith.pillar.{pillar_id}.{event_type}). Kelly manages Pillar 1–2, "
    "Compass manages Pillar 3–4, Atlas manages Pillar 5–6.")
S46 += bullet("Consumer Layer: All 28 agents subscribe to relevant topics via consumer groups "
    "(group_id: monolith.agents.{agent_id}). Offset management ensures exactly-once delivery "
    "for financial and approval events; at-least-once for informational events.")
S46 += bullet("Observability Layer: Kafka topic lag monitoring via Prometheus + Grafana dashboards "
    "(integrated with WS-B telemetry infrastructure). Alert thresholds: consumer lag > 100 msgs "
    "triggers Pulse agent notification to Forge (Infrastructure).")

S46 += heading2("46.5  Delivery Checklist (SVC-WS-C-01–06)")
S46 += label_value("SVC-WS-C-01", "Cross-Pillar Event Bus src/event-bus/ v1.0 — EVT-001 schema registered, all 6 pillar topics created. Target: Q2 2031.")
S46 += label_value("SVC-WS-C-02", "EVT-002 trigger rules deployed — 8 cross-pillar automation rules live, tested on 2 pilot projects. Target: Q3 2031.")
S46 += label_value("SVC-WS-C-03", "Client portal src/client-portal/ v1.0 — real-time project status, concept preview, approval workflow. Target: Q3 2031.")
S46 += label_value("SVC-WS-C-04", "Digital twin preview — Three.js web viewer integrated with BIM (S20) + AIE-002 texturing. Target: Q3 2031.")
S46 += label_value("SVC-WS-C-05", "Post-project intelligence — automated POE survey + NPS scoring + quarterly reports active. Target: Q4 2031.")
S46 += label_value("SVC-WS-C-06", "WS-C UAT: 3 live projects E2E tested — event bus, portal, preview, intelligence reporting validated. Target: Q4 2031.")

S46 += heading2("46.6  Governance, Dependencies & Agent Assignments")
S46 += body(
    "WS-C Programme Director: Core (Group D, ≥97%). Client Experience Lead: Kelly (Group A, ≥95%). "
    "Event Bus Lead: Ops (Group C, ≥94%). Client Portal Lead: Shore (Group B, ≥93%). "
    "Data Intelligence Lead: Atlas (Group C, ≥94%)."
)
S46 += body(
    "Dependencies: S45 WS-B (Kafka infrastructure prerequisite for EVT-001–005), "
    "S40 (Design Freeze Gate — EVT-002 trigger integration), S41 (Sensory Commissioning — EVT-002 trigger), "
    "S42 (POE — SVC-WS-C-04 post-project intelligence), S45 AIE-002 (digital twin texturing), "
    "S20 (BIM — digital twin floor plan data). Client portal requires PDPA compliance review (S15 + GAP-10)."
)

S46 += heading2("46.7  Milestones (WS-C-M1–M4)")
S46 += label_value("WS-C-M1 (Q2 2031)", "Cross-Pillar Event Bus live — all pillar topics, EVT-001 schema, and consumer groups active.")
S46 += label_value("WS-C-M2 (Q3 2031)", "Client portal v1.0 launched — real-time status, preview, approval workflow, pilot client group onboarded.")
S46 += label_value("WS-C-M3 (Q3 2031)", "EVT-002 trigger rules live — 8 cross-pillar automations verified on 2 pilot projects, GAP-06 closed.")
S46 += label_value("WS-C-M4 (Q4 2031)", "WS-C UAT passed — all 6 checklist items complete, client NPS target ≥70 achieved on pilot projects.")

# ============================================================
# SECTION 47 — Real-time KPI Dashboard (GAP-08) — Phase 1 Roadmap Completion
# ============================================================
S47 = ""
S47 += heading1("47. Real-time KPI Dashboard (GAP-08) — AMD-004 WS-D Phase 1 Roadmap Completion")
S47 += heading2("47.1  Overview & Phase 1 Significance")
S47 += body(
    "Section 47 closes GAP-08 (Real-time KPI Dashboard) — the final HIGH-priority gap in Phase 1 of the "
    "Gap Resolution Roadmap, completing all six Phase 1 targets (GAP-01 through GAP-04, GAP-07, GAP-08). "
    "With this section, the MONOLITH DAPH Decor programme achieves the Phase 1 coverage target of 68% "
    "(up from the baseline 56% recorded in the September 2026 SOP-GitHub Coverage Analysis). "
    "The Real-time KPI Dashboard is the central operations visibility layer for the 28-agent programme, "
    "consolidating SLA performance, project health, financial tracking, and client satisfaction metrics "
    "into a single unified interface accessible to the Steering Committee and Programme Directors."
)
S47 += body(
    "This section falls under AMD-004 Workstream D (Data & Analytics Maturity Enhancement, ฿0.9M, S38.8.4). "
    "Timeline: Q3–Q4 2030 (Phase 1 — earliest delivery, enabling SC oversight from programme start). "
    "Primary Agents: Atlas (Analytics Intelligence, Group C ≥94%), Ledger (Financial Tracking, Group D ≥97%), "
    "Pulse (Performance Monitoring, Group C ≥94%), Nexus (System Integration, Group D ≥97%)."
)

S47 += heading2("47.2  Dashboard Architecture")
S47 += body(
    "The Real-time KPI Dashboard is built on three integrated layers that leverage existing "
    "monolith-workspace infrastructure and the new WS-B data pipeline (S45.2 INFRA-WS-B-03):"
)
S47 += label_value("Layer 1 — Data Collection", "Event streams from Kafka (WS-B/S45) + direct Supabase queries (src/core/supabase/). "
    "Data sources: agent SLA logs (all 28 agents), project milestone events (Pillar Event Bus S46.3), "
    "financial transactions (Ledger agent), client interaction logs (Shore/Kelly agents), "
    "POE survey results (Scout agent). Refresh cadence: real-time (Kafka) + 15-min batch (Supabase).")
S47 += label_value("Layer 2 — Analytics & Aggregation", "Dedicated analytics service in src/analytics/ (existing module, extended under WS-D). "
    "Pre-computed KPI aggregations: rolling 7/30/90-day SLA averages per agent, project health index "
    "(weighted: timeline 40% + budget 30% + client satisfaction 30%), pillar coverage delta tracking, "
    "AMD programme milestone burn-rate.")
S47 += label_value("Layer 3 — Visualisation & Alerting", "React-based dashboard (src/dashboard/ — new module) served via WS-B API Gateway. "
    "Role-based views: SC view (programme KPIs, phase completion, risk register), "
    "Programme Director view (agent SLA, project health, financial burn), "
    "Agent supervisor view (individual agent metrics, queue depth, SLA countdown). "
    "Alert engine: Pulse agent broadcasts SC-prioritised alerts at defined thresholds.")

S47 += heading2("47.3  KPI Framework — Core Metrics")
S47 += body(
    "The dashboard tracks four KPI categories mandatory for World-Class AI Agent programme governance:"
)
S47 += label_value("SLA Performance KPIs (KPI-001–007)", "Per-agent SLA compliance rate (Group A ≥95%, B ≥93%, C ≥94%, D ≥97%). "
    "Weekly SLA breach count, mean time to recovery (MTTR), agent availability uptime. "
    "Pillar coverage completeness: current % per pillar vs Phase 1/2/3 targets. "
    "Dashboard alert: RED if any agent group SLA drops below threshold for 3 consecutive days.")
S47 += label_value("Project Health KPIs (KPI-008–014)", "Active project count, on-time delivery rate (target ≥90%), budget variance (target ≤5%), "
    "design freeze compliance (% projects hitting DFG gate S40 without scope creep), "
    "client approval turnaround (target ≤48hrs for concept approval). "
    "Design iteration count per project (AI Creative Engine S45.3 AIE-005 tracking).")
S47 += label_value("Financial Performance KPIs (KPI-015–019)", "AMD programme spend vs plan: WS-A through WS-E monthly burn rate vs ฿5.2M budget. "
    "Project revenue recognition timeline, client invoice ageing (Ledger agent), "
    "cost-per-delivered-section (AMD workstream efficiency metric). "
    "SC-2030-01 to SC-2030-05 gate budget consumption tracking.")
S47 += label_value("Client Experience KPIs (KPI-020–024)", "NPS score (target ≥70), client satisfaction index per project (post-POE survey S42), "
    "WELL/LEED certification achievement rate, repeat client rate, referral rate. "
    "Real-time client portal engagement (active sessions, approval response time).")

S47 += heading2("47.4  Phase 1 Gap Closure Summary")
S47 += body(
    "With Section 47 accepted, Phase 1 of the Gap Resolution Roadmap is formally complete. "
    "The following HIGH-priority gaps are now covered by corresponding SOP sections and GitHub module specifications:"
)
S47 += label_value("GAP-01 (Biophilic Module)", "Closed by S39 — Biophilic Design Framework, WELL v2 features, src/biophilic/ spec, BIO-WS-01–05.")
S47 += label_value("GAP-02 (Design Freeze Gate)", "Closed by S40 — Design Freeze Gate Protocol, DFG-WS-01–06, src/design-freeze/ spec.")
S47 += label_value("GAP-03 (Sensory Commissioning)", "Closed by S41 — 5-sense commissioning protocol, SCP-WS-01–05, src/sensory-commissioning/ spec.")
S47 += label_value("GAP-04 (POE Framework)", "Closed by S42 — Post-Occupancy Evaluation Framework, POE-WS-01–05, src/poe/ spec.")
S47 += label_value("GAP-07 (SC Governance Dashboard)", "Closed by S43 — SC Governance Module, GOV-AMD4-01–06, src/sc-governance/ spec.")
S47 += label_value("GAP-08 (Real-time KPI Dashboard)", "Closed by S47 (this section) — KPI Framework KPI-001–024, src/dashboard/ spec, WS-D delivery.")

S47 += heading2("47.5  Delivery Checklist (KPI-WS-D-01–05)")
S47 += label_value("KPI-WS-D-01", "Kafka data pipeline connected to analytics layer — all 28 agent SLA streams live. Target: Q3 2030.")
S47 += label_value("KPI-WS-D-02", "Analytics service extended — KPI-001 to KPI-024 pre-computed aggregations verified. Target: Q3 2030.")
S47 += label_value("KPI-WS-D-03", "Dashboard src/dashboard/ v1.0 deployed — SC view, Programme Director view, Agent view active. Target: Q4 2030.")
S47 += label_value("KPI-WS-D-04", "Alert engine via Pulse agent — 12 alert rules live, SC escalation tested (SC-2030-01 governance chain). Target: Q4 2030.")
S47 += label_value("KPI-WS-D-05", "Phase 1 coverage verification report published — GAP-01 to GAP-08 formal closure confirmed by Atlas agent. Target: Q4 2030.")

S47 += heading2("47.6  Governance, Dependencies & Agent Assignments")
S47 += body(
    "WS-D is governed under SC-2030-01 (AMD-004 programme authorisation). "
    "Analytics Lead: Atlas (Group C, ≥94%). Dashboard Lead: Frame (Group C, ≥94%). "
    "Financial KPI: Ledger (Group D, ≥97%). Alert Management: Pulse (Group C, ≥94%). "
    "System Integration: Nexus (Group D, ≥97%). SC Reporting: Vega (Group D, ≥97%)."
)
S47 += body(
    "Phase 1 dependencies: S38 (AMD-004 PDD — programme budget and SC gate), S39–S43 (Phase 1 gap sections — "
    "data sources for coverage KPIs), S45 WS-B (Kafka infrastructure for real-time data ingestion), "
    "src/core/telemetry/ (existing telemetry → KPI feed), src/core/supabase/ (SLA and project data store)."
)

S47 += heading2("47.7  Milestones (KPI-M1–M4)")
S47 += label_value("KPI-M1 (Q3 2030)", "KPI data pipeline and analytics layer live — all agent SLA streams ingesting, KPI-001–024 computed.")
S47 += label_value("KPI-M2 (Q4 2030)", "Dashboard v1.0 launched — SC and Programme Director views deployed, first SC review cycle completed.")
S47 += label_value("KPI-M3 (Q4 2030)", "Alert engine active — Pulse agent broadcasting SLA alerts, GAP-08 formally closed.")
S47 += label_value("KPI-M4 (Q4 2030)", "Phase 1 Roadmap completion certificate issued — coverage confirmed at ≥68%, SC-2030-01 Phase 1 gate passed.")

# ============================================================
# ASSEMBLE & INJECT
# ============================================================
NEW_CONTENT = S45 + S46 + S47

# Insert before </w:body>
if '</w:body>' in xml:
    xml = xml.replace('</w:body>', NEW_CONTENT + '</w:body>', 1)
    print("Injection point: </w:body>")
else:
    raise ValueError("Cannot find </w:body> in document XML")

# Write new DOCX
all_files['word/document.xml'] = xml.encode('utf-8')

with zipfile.ZipFile(DST, 'w', compression=zipfile.ZIP_DEFLATED) as zout:
    for name, data in all_files.items():
        zout.writestr(name, data)

# Verify
with zipfile.ZipFile(DST, 'r') as z:
    vxml = z.read('word/document.xml').decode('utf-8')
    ins_list = re.findall(r'w:id="(\d+)"', vxml)
    ins_tags = re.findall(r'<w:ins[ >]', vxml)
    s45 = 'AMD-004 WS-B' in vxml
    s46 = 'AMD-004 WS-C' in vxml
    s47 = 'GAP-08' in vxml and 'KPI-M4' in vxml

print(f"\n=== INJECTION RESULTS ===")
print(f"w:ins tracked insertions: {len(ins_tags)}")
print(f"Max ID used: {max(int(x) for x in ins_list) if ins_list else 0}")
print(f"S45 (WS-B) present: {s45}")
print(f"S46 (WS-C) present: {s46}")
print(f"S47 (GAP-08/KPI) present: {s47}")
print(f"File size: {os.path.getsize(DST):,} bytes")
print(f"IDs used: 673 – {_id - 1} (total {_id - 673} IDs allocated)")
