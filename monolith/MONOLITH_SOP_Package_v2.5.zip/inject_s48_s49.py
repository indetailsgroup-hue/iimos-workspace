"""
inject_s48_s49.py
Inject Sections S48–S49 into monolith_project_summary_v25_accepted.docx
S48: AMD-004 WS-E Human Capital & Change Management (Training & Change Mgmt)
S49: AMD-004 Programme Closure & Phase 2 Gateway
IDs start at 959 (continuing from inject_s45_s47.py which used 673–958)
"""
import zipfile, re, shutil, os

SRC = '/home/sandbox/monolith_project_summary_v25_accepted.docx'
DST = '/home/sandbox/monolith_project_summary_v25_accepted.docx'
BAK = '/home/sandbox/monolith_project_summary_v25_accepted_pre_s48_backup.docx'

shutil.copy(SRC, BAK)
print(f'Backup: {BAK}')

with zipfile.ZipFile(SRC, 'r') as z:
    xml = z.read('word/document.xml').decode('utf-8')
    all_files = {name: z.read(name) for name in z.namelist()}

_id = 959

def nid():
    global _id
    v = _id
    _id += 1
    return v

AUTHOR = "Scispace Agent"
DATE   = "2026-09-03T00:00:00Z"

def heading1(text):
    pi, ri = nid(), nid()
    return (
        f'<w:p><w:pPr><w:spacing w:before="320" w:after="100"/>'
        f'<w:rPr><w:ins w:id="{pi}" w:author="{AUTHOR}" w:date="{DATE}"/></w:rPr></w:pPr>'
        f'<w:ins w:id="{ri}" w:author="{AUTHOR}" w:date="{DATE}">'
        f'<w:r><w:rPr><w:b/><w:bCs/><w:sz w:val="36"/><w:szCs w:val="36"/>'
        f'<w:color w:val="1f2d5a"/></w:rPr>'
        f'<w:t xml:space="preserve">{text}</w:t></w:r></w:ins></w:p>\n'
    )

def heading2(text):
    pi, ri = nid(), nid()
    return (
        f'<w:p><w:pPr><w:spacing w:before="200" w:after="80"/>'
        f'<w:rPr><w:ins w:id="{pi}" w:author="{AUTHOR}" w:date="{DATE}"/></w:rPr></w:pPr>'
        f'<w:ins w:id="{ri}" w:author="{AUTHOR}" w:date="{DATE}">'
        f'<w:r><w:rPr><w:b/><w:bCs/><w:sz w:val="28"/><w:szCs w:val="28"/>'
        f'<w:color w:val="2e75b6"/></w:rPr>'
        f'<w:t xml:space="preserve">{text}</w:t></w:r></w:ins></w:p>\n'
    )

def body(text, indent=400):
    pi, ri = nid(), nid()
    return (
        f'<w:p><w:pPr><w:spacing w:before="0" w:after="80"/>'
        f'<w:ind w:left="{indent}"/>'
        f'<w:rPr><w:ins w:id="{pi}" w:author="{AUTHOR}" w:date="{DATE}"/></w:rPr></w:pPr>'
        f'<w:ins w:id="{ri}" w:author="{AUTHOR}" w:date="{DATE}">'
        f'<w:r><w:rPr><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>'
        f'<w:t xml:space="preserve">{text}</w:t></w:r></w:ins></w:p>\n'
    )

def bullet(text):
    pi, ri = nid(), nid()
    return (
        f'<w:p><w:pPr><w:spacing w:before="0" w:after="60"/>'
        f'<w:ind w:left="600" w:hanging="200"/>'
        f'<w:rPr><w:ins w:id="{pi}" w:author="{AUTHOR}" w:date="{DATE}"/></w:rPr></w:pPr>'
        f'<w:ins w:id="{ri}" w:author="{AUTHOR}" w:date="{DATE}">'
        f'<w:r><w:rPr><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr>'
        f'<w:t xml:space="preserve">&#x2022; {text}</w:t></w:r></w:ins></w:p>\n'
    )

def label_value(label, value):
    pi, r1, r2 = nid(), nid(), nid()
    return (
        f'<w:p><w:pPr><w:spacing w:before="0" w:after="60"/>'
        f'<w:ind w:left="600"/>'
        f'<w:rPr><w:ins w:id="{pi}" w:author="{AUTHOR}" w:date="{DATE}"/></w:rPr></w:pPr>'
        f'<w:ins w:id="{r1}" w:author="{AUTHOR}" w:date="{DATE}">'
        f'<w:r><w:rPr><w:b/><w:bCs/><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr>'
        f'<w:t xml:space="preserve">{label}:  </w:t></w:r></w:ins>'
        f'<w:ins w:id="{r2}" w:author="{AUTHOR}" w:date="{DATE}">'
        f'<w:r><w:rPr><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr>'
        f'<w:t xml:space="preserve">{value}</w:t></w:r></w:ins></w:p>\n'
    )

# ============================================================
# SECTION 48 — AMD-004 WS-E: Human Capital & Change Management
# Training Programme + Change Management Framework
# ============================================================
S48 = ""
S48 += heading1("Section 48 — AMD-004 WS-E: Human Capital & Change Management")
S48 += body(
    "Section 48 documents Workstream E (WS-E) of the AMD-004 Decor AI Agent Programme — "
    "the human capital and change management workstream responsible for embedding the "
    "28-agent AI architecture into day-to-day operations through structured training and "
    "organisational change. WS-E is the final workstream of AMD-004, budget THB 0.6M, "
    "delivery Q1–Q2 2032."
)

S48 += heading2("48.1  ภาพรวม WS-E (Workstream E Overview)")
S48 += body(
    "WS-E ครอบคลุมมิติด้านทุนมนุษย์ของโครงการ AMD-004: การฝึกอบรมบุคลากร การรับรองการใช้เครื่องมือ AI "
    "และการบริหารการเปลี่ยนแปลงเพื่อให้สถาปัตยกรรม 28 AI Agent ฝังรากอยู่ในกระบวนการปฏิบัติงานจริง "
    "WS-E เป็น Workstream สุดท้ายของ AMD-004 ที่รับประกันว่าทีมงานมีความพร้อมในการดำเนินงานอย่างยั่งยืน "
    "หลังจากการติดตั้งระบบเทคนิคเสร็จสมบูรณ์ใน WS-A ถึง WS-D"
)
S48 += label_value("Programme", "AMD-004 Decor AI Agent Architecture — Workstream E")
S48 += label_value("Authorising document", "SC-2030-01 (AMD-004 Programme Definition Document, Section 38)")
S48 += label_value("Budget", "THB 0.6M")
S48 += label_value("Timeline", "Q1–Q2 2032")
S48 += label_value("Owner", "Talent (Group D, SLA ≥97%)")
S48 += label_value("Support agents", "Core (Group D, ≥97%), Hana (Group B, ≥93%), Nova (Group A, ≥95%)")

S48 += heading2("48.2  ขอบเขตงาน (Scope of Work)")
S48 += body(
    "WS-E ครอบคลุมงาน 4 สาขาหลัก ได้แก่ (1) การออกแบบและดำเนินโครงการฝึกอบรม "
    "(2) การรับรองการใช้เครื่องมือ AI สำหรับบุคลากรทุกระดับ "
    "(3) กรอบการบริหารการเปลี่ยนแปลงองค์กร "
    "และ (4) การวัดผลการนำระบบไปใช้จริง (Adoption Metrics)"
)
S48 += bullet("ออกแบบหลักสูตรฝึกอบรม 4 ชุด (TRN-001–004) สำหรับบุคลากรทุกบทบาท — Agent Operators, Designers, Client Managers, SC Members")
S48 += bullet("จัดทำระบบการรับรอง AI Tool Certification สำหรับการใช้งาน Agent ในงาน Interior Design Workflow")
S48 += bullet("วิเคราะห์ผู้มีส่วนได้เสียและออกแบบแผนการสื่อสาร (CHG-001–002) ครอบคลุมทุก Stakeholder Group")
S48 += bullet("สร้างกลไกจัดการความต้านทานต่อการเปลี่ยนแปลง (CHG-003) และวัดผล Adoption (CHG-004)")
S48 += bullet("ออกแบบ Onboarding Program สำหรับ New Joiners เพื่อให้ครอบคลุม AMD-004 Architecture ตั้งแต่วันแรก")
S48 += bullet("สร้าง Knowledge Base และ SOP Quick Reference สำหรับ 28 AI Agents — ภาษาไทยและภาษาอังกฤษ")

S48 += heading2("48.3  งบประมาณและกรอบเวลา (Budget & Timeline)")
S48 += body(
    "WS-E มีงบประมาณ THB 0.6M ซึ่งเป็นส่วนหนึ่งของงบประมาณรวม AMD-004 ทั้งหมด THB 5.2M "
    "โดยอนุมัติภายใต้ SC-2030-01 ดำเนินการใน Q1–Q2 2032 ซึ่งเป็นระยะสุดท้ายของโครงการ"
)
S48 += label_value("WS-E Total Budget", "THB 0.6M")
S48 += label_value("Training Design & Development", "THB 0.18M (30% of WS-E)")
S48 += label_value("Training Delivery & Facilitation", "THB 0.15M (25% of WS-E)")
S48 += label_value("Change Management Consulting", "THB 0.12M (20% of WS-E)")
S48 += label_value("Materials, Platform & Certification System", "THB 0.09M (15% of WS-E)")
S48 += label_value("Adoption Monitoring & Evaluation", "THB 0.06M (10% of WS-E)")
S48 += label_value("Q1 2032 Activities", "Stakeholder analysis, curriculum design, pilot delivery (TRN-001–002)")
S48 += label_value("Q2 2032 Activities", "Full rollout (TRN-003–004), change management closure, adoption metrics baseline")

S48 += heading2("48.4  Training Programme (TRN-001–004)")
S48 += body(
    "โปรแกรมการฝึกอบรม WS-E ประกอบด้วย 4 ชุดการเรียนรู้ครอบคลุมบุคลากรทุกบทบาทในองค์กร "
    "ตั้งแต่ทีมปฏิบัติการ Agent Operations ไปจนถึงทีมบริการลูกค้าและคณะกรรมการ SC"
)
S48 += label_value("TRN-001 Agent Operations Training",
    "หลักสูตร 16 ชั่วโมง — สถาปัตยกรรม 28 AI Agents, SLA Groups A–D, "
    "Orchestration Workflow, Escalation Procedures. กลุ่มเป้าหมาย: Project Managers, Design Leads. "
    "รูปแบบ: Workshop 2 วัน + E-learning Self-paced. ผู้รับผิดชอบ: Talent + Core.")
S48 += label_value("TRN-002 AI Tool Certification",
    "การรับรองมาตรฐาน 3 ระดับ (Bronze/Silver/Gold) สำหรับการใช้งาน AI Tools ในกระบวนการออกแบบ "
    "Interior Design — Concept Generation, Material Selection, Spatial Planning. "
    "กลุ่มเป้าหมาย: Designers, Creative Leads. ผู้รับผิดชอบ: Nova + Hana.")
S48 += label_value("TRN-003 Design Process Re-engineering",
    "Workshop 8 ชั่วโมง — การปรับกระบวนการออกแบบใหม่โดยใช้ AI-augmented workflow "
    "ครอบคลุม Biophilic Design Integration (GAP-01), Material Sustainability (covered in Pillar 2–5), "
    "POE Feedback Loop (GAP-03/04). กลุ่มเป้าหมาย: All Design Staff. ผู้รับผิดชอบ: Talent.")
S48 += label_value("TRN-004 Client-Facing AI Usage",
    "หลักสูตร 4 ชั่วโมง — การสื่อสารกับลูกค้าเกี่ยวกับ AI-assisted Design, "
    "Client Portal Walkthrough, AI Transparency Guidelines. "
    "กลุ่มเป้าหมาย: Client Managers, Account Leads. ผู้รับผิดชอบ: Nova.")

S48 += heading2("48.5  Change Management Framework (CHG-001–004)")
S48 += body(
    "กรอบการบริหารการเปลี่ยนแปลงของ WS-E ใช้แนวทาง ADKAR (Awareness–Desire–Knowledge–Ability–Reinforcement) "
    "ปรับให้เหมาะสมกับบริบทการนำ AI มาใช้ในงานออกแบบตกแต่งภายใน"
)
S48 += label_value("CHG-001 Stakeholder Analysis",
    "วิเคราะห์และจัดลำดับ Stakeholders ทั้งหมดตามระดับผลกระทบและความพร้อมรับการเปลี่ยนแปลง "
    "ครอบคลุม SC Members, Programme Director, Design Teams, Client-facing Staff, IT Operations. "
    "ผลลัพธ์: Stakeholder Map + Engagement Strategy. กำหนดส่ง: Q1 2032.")
S48 += label_value("CHG-002 Communication Plan",
    "แผนการสื่อสารครอบคลุม: Timeline การประกาศเปิดตัว AMD-004, FAQs สำหรับบุคลากรทุกกลุ่ม, "
    "Progress Updates รายไตรมาส, Success Story Sharing. "
    "ช่องทาง: All-hands meetings, Intranet, Line Official, SC Reports. กำหนดส่ง: Q1 2032.")
S48 += label_value("CHG-003 Resistance Management",
    "กลไกระบุและจัดการความต้านทาน: Anonymous Feedback Channels, Champion Network (1 ต่อทีม), "
    "Escalation Path สำหรับความกังวลที่ซับซ้อน, 30/60/90-day Check-ins. "
    "ผู้รับผิดชอบ: Hana (Group B, ≥93%). กำหนดดำเนินการ: ตลอด Q1–Q2 2032.")
S48 += label_value("CHG-004 Adoption Metrics",
    "ตัวชี้วัดการนำระบบไปใช้จริง: Training Completion Rate ≥90%, Certification Pass Rate ≥80%, "
    "AI Tool Active Usage ≥70% of Design Staff within 90 days, "
    "Client Satisfaction Score ≥4.2/5.0 post-AI integration, "
    "Agent SLA Achievement ≥ target levels per Group A–D. ผู้รับผิดชอบ: Talent + Pulse.")

S48 += heading2("48.6  รายการตรวจสอบ WS-E (TRN-WS-E-01–05)")
S48 += label_value("TRN-WS-E-01",
    "Training Needs Analysis completed — all roles mapped to training modules TRN-001–004, "
    "gap analysis validated by Programme Director. Target: Q1 2032.")
S48 += label_value("TRN-WS-E-02",
    "TRN-001 & TRN-002 pilot delivery completed — minimum 20 participants, feedback score ≥4.0/5.0, "
    "curriculum adjustments incorporated. Target: Q1 2032.")
S48 += label_value("TRN-WS-E-03",
    "TRN-003 & TRN-004 full rollout completed — all eligible staff certified, "
    "AI Tool Certification Bronze achieved by 100% of Design Staff. Target: Q2 2032.")
S48 += label_value("TRN-WS-E-04",
    "Change Management Framework CHG-001–004 executed — Stakeholder Map published, "
    "Communication Plan active, Resistance Management channels operational, "
    "Adoption Metrics baseline recorded. Target: Q2 2032.")
S48 += label_value("TRN-WS-E-05",
    "WS-E Closure Report submitted to SC — Training Completion ≥90%, Adoption Metrics baseline confirmed, "
    "Knowledge Base published (TH/EN), WS-E formally closed under SC-2030-01. Target: Q2 2032.")

S48 += heading2("48.7  Milestones WS-E-M1–WS-E-M4")
S48 += label_value("WS-E-M1 (Q1 2032)",
    "Training programme designed and piloted — TRN-001 & TRN-002 pilot complete, "
    "CHG-001 Stakeholder Analysis published, Communication Plan activated.")
S48 += label_value("WS-E-M2 (Q1 2032)",
    "Full training rollout commenced — TRN-003 & TRN-004 delivery started, "
    "CHG-003 Resistance Management channels operational, CHG-002 mid-programme communications live.")
S48 += label_value("WS-E-M3 (Q2 2032)",
    "All training streams completed — 100% staff coverage achieved, AI Tool Certification issued, "
    "CHG-004 Adoption Metrics 30-day baseline recorded.")
S48 += label_value("WS-E-M4 (Q2 2032)",
    "WS-E formally closed — TRN-WS-E-01–05 all ticked, WS-E Closure Report accepted by SC, "
    "AMD-004 Programme ready for Programme Closure gate (Section 49).")

# ============================================================
# SECTION 49 — AMD-004 Programme Closure & Phase 2 Gateway
# ============================================================
S49 = ""
S49 += heading1("Section 49 — AMD-004 Programme Closure & Phase 2 Gateway")
S49 += body(
    "Section 49 is the formal Programme Closure section for AMD-004 Decor AI Agent Architecture. "
    "It consolidates all five workstreams (WS-A through WS-E), confirms the Phase 1 completion "
    "certificate covering GAP-01/02/03/04/07/08, and establishes the Phase 2 Readiness Gate "
    "for GAP-05/06/09/10/11/12. Total programme investment: THB 5.2M."
)

S49 += heading2("49.1  ภาพรวม AMD-004 Programme Closure")
S49 += body(
    "การปิดโครงการ AMD-004 (Programme Closure) ถือเป็นจุดสิ้นสุดของ Phase 1 "
    "ของการพัฒนา Decor AI Agent Architecture โดย MONOLITH DAPH "
    "ครอบคลุมระยะเวลาดำเนินงานตั้งแต่ Q3 2030 ถึง Q2 2032 รวม 8 ไตรมาส "
    "งบประมาณรวม THB 5.2M และผลลัพธ์คือการยกระดับ AI Coverage จาก 56% เป็น 68% "
    "ผ่านการปิด GAP 6 รายการจาก 15 รายการ (GAP-01/02/03/04/07/08)"
)
S49 += label_value("Programme", "AMD-004 Decor AI Agent Architecture — MONOLITH DAPH")
S49 += label_value("Authorising SC Resolution", "SC-2030-01")
S49 += label_value("Programme Start", "Q3 2030 (WS-A & WS-D commencement)")
S49 += label_value("Programme End (Phase 1)", "Q2 2032 (WS-E closure)")
S49 += label_value("Total Budget", "THB 5.2M (all 5 workstreams)")
S49 += label_value("Phase 1 Coverage Achievement", "56% → 68% (+12 percentage points)")
S49 += label_value("GAPs Closed in Phase 1", "GAP-01, GAP-02, GAP-03, GAP-04, GAP-07, GAP-08 (6 of 15)")
S49 += label_value("Programme Director", "Core (Group D, SLA ≥97%)")

S49 += heading2("49.2  สรุปทุก Workstream (WS-A through WS-E)")
S49 += body(
    "AMD-004 ประกอบด้วย 5 Workstream ที่ดำเนินการต่อเนื่องกัน ตั้งแต่การวางโครงสร้างพื้นฐานทางกฎหมาย "
    "ไปจนถึงการพัฒนาทักษะบุคลากร ทุก Workstream เชื่อมโยงและส่งต่อผลลัพธ์ระหว่างกัน"
)
S49 += label_value("WS-A Corporate Governance & Regulatory Alignment",
    "THB 0.8M | Q3–Q4 2030 | Status: Completed. "
    "Output: SC-2030-01 Programme Resolution, Regulatory Compliance Framework, "
    "28-agent Governance Charter. Owner: Guardian (Group D, ≥97%).")
S49 += label_value("WS-B Technology Infrastructure Next Generation",
    "THB 1.1M | Q1–Q3 2031 | Status: Completed. "
    "Output: Kafka event bus, Supabase multi-tenant schema, Microservices mesh, "
    "API Gateway, Cloud infrastructure. Owner: Nexus (Group D, ≥97%). GAP-05 partial.")
S49 += label_value("WS-C Client Service Innovation Delivery",
    "THB 1.2M | Q2–Q4 2031 | Status: Completed. "
    "Output: Client Portal v2.0, AI-assisted Design Consultation Module, "
    "CRM-Agent integration, NPS tracking. Owner: Scout (Group B, ≥93%). GAP-06 partial.")
S49 += label_value("WS-D Real-time Analytics & KPI Dashboard",
    "THB 0.9M | Q3–Q4 2030 | Status: Completed. "
    "Output: KPI Framework (KPI-001–024), Real-time Dashboard, Alert Engine, "
    "Phase 1 Completion Certificate. Owner: Atlas (Group C, ≥94%). GAP-08 closed.")
S49 += label_value("WS-E Human Capital & Change Management",
    "THB 0.6M | Q1–Q2 2032 | Status: Completed (Section 48). "
    "Output: Training Programme TRN-001–004, AI Tool Certification, "
    "Change Management Framework CHG-001–004, Adoption Metrics baseline. Owner: Talent (Group D, ≥97%).")

S49 += heading2("49.3  งบประมาณรวม THB 5.2M (Programme Budget Summary)")
S49 += body(
    "งบประมาณรวม AMD-004 อนุมัติโดย SC ภายใต้ SC-2030-01 แบ่งตาม Workstream ดังนี้ "
    "รวม THB 5.2M ครอบคลุมระยะดำเนินการ 8 ไตรมาส (Q3 2030 – Q2 2032)"
)
S49 += label_value("WS-A Corporate Governance", "THB 0.8M (15.4% of total)")
S49 += label_value("WS-B Technology Infrastructure", "THB 1.1M (21.2% of total)")
S49 += label_value("WS-C Client Service Innovation", "THB 1.2M (23.1% of total)")
S49 += label_value("WS-D Analytics & KPI Dashboard", "THB 0.9M (17.3% of total)")
S49 += label_value("WS-E Human Capital & Change Mgmt", "THB 0.6M (11.5% of total)")
S49 += label_value("Programme Contingency (6.5%)", "THB 0.6M (reserved under SC-2030-01)")
S49 += label_value("TOTAL AMD-004 PROGRAMME", "THB 5.2M")
S49 += body(
    "Programme contingency THB 0.6M ถูกบริหารโดย Core (Group D) ภายใต้การกำกับของ SC "
    "การใช้จ่าย Contingency ทุกรายการต้องผ่านการอนุมัติ SC และบันทึกใน Programme Change Log"
)

S49 += heading2("49.4  Phase 1 Completion Certificate (GAP-01/02/03/04/07/08)")
S49 += body(
    "ใบรับรองการสำเร็จ Phase 1 ยืนยันการปิด GAP ทั้ง 6 รายการที่กำหนดไว้ใน Phase 1 Roadmap "
    "ซึ่งยกระดับ AI Coverage ของ MONOLITH DAPH จาก 56% เป็น 68%"
)
S49 += label_value("GAP-01 Biophilic Design Intelligence",
    "CLOSED — Section 39, Pillar 1 Biophilic Integration SOP. "
    "Agent: Blaze (Group A, ≥95%). Coverage contribution: +2%. src/biophilic/")
S49 += label_value("GAP-02 Design Freeze Gate Enforcement",
    "CLOSED — Section 40, Pillar 2 Design Freeze Gate SOP. "
    "Agent: Signal (Group A, ≥95%). Coverage contribution: +2%. src/design-freeze/")
S49 += label_value("GAP-03 Sensory Commissioning Protocol",
    "CLOSED — Section 41, Pillar 6 Sensory Commissioning SOP. "
    "Agent: Ember (Group B, ≥93%). Coverage contribution: +1%. src/sensory/")
S49 += label_value("GAP-04 Post-Occupancy Evaluation (POE)",
    "CLOSED — Section 42, POE Framework & Feedback Loop SOP. "
    "Agent: Shore (Group B, ≥93%). Coverage contribution: +2%. src/poe/")
S49 += label_value("GAP-07 SC Governance Dashboard",
    "CLOSED — Section 43, SC Governance Module SOP. "
    "Agent: Vega (Group D, ≥97%). Coverage contribution: +2%. src/sc-governance/")
S49 += label_value("GAP-08 Real-time KPI Dashboard",
    "CLOSED — Section 47, WS-D KPI Framework SOP. "
    "Agent: Frame (Group C, ≥94%). Coverage contribution: +3%. src/dashboard/")
S49 += body(
    "Phase 1 Coverage Verification: Atlas (Group C, ≥94%) ดำเนินการตรวจสอบ Coverage ผ่าน "
    "KPI-018 (SOP Coverage Score) และ KPI-019 (Gap Closure Rate) "
    "ยืนยัน Coverage ≥68% ภายใน Q4 2030 (KPI-WS-D-05). "
    "Phase 1 Completion Certificate ออกโดย Core (Group D) และเสนอต่อ SC เพื่อรับทราบ"
)

S49 += heading2("49.5  Phase 2 Readiness Gate (GAP-05/06/09/10/11/12)")
S49 += body(
    "Phase 2 Readiness Gate กำหนดเงื่อนไขเริ่มต้น Phase 2 ที่มุ่งยกระดับ AI Coverage จาก 68% เป็น 80% "
    "ครอบคลุม GAP 6 รายการ ได้แก่ GAP-05, GAP-06, GAP-09, GAP-10, GAP-11, GAP-12 "
    "การผ่าน Phase 2 Gate ต้องได้รับการอนุมัติจาก SC ก่อนเริ่มงบประมาณ Phase 2"
)
S49 += label_value("GAP-05 AI Creative Engine (Cross-Pillar AI)",
    "OPEN — Phase 2 Target. WS-B infrastructure prerequisite met. "
    "Requires: AI Creative Engine spec completion, SC approval for Phase 2 budget. "
    "Responsible Agent: Kelly (Group A, ≥95%). Target: Phase 2 Q1–Q2 2033.")
S49 += label_value("GAP-06 Cross-Pillar Event Bus Integration",
    "OPEN — Phase 2 Target. WS-B Kafka infrastructure in place. "
    "Requires: Event schema definition, agent subscription model, full integration testing. "
    "Responsible Agent: Compass (Group B, ≥93%). Target: Phase 2 Q2–Q3 2033.")
S49 += label_value("GAP-09 Sustainable Material Intelligence",
    "OPEN — Phase 2 Target. Medium priority. "
    "Requires: Material database integration, sustainability scoring model. "
    "Responsible Agent: Forge (Group C, ≥94%). Target: Phase 2 Q1 2033.")
S49 += label_value("GAP-10 Contractor & Vendor Management AI",
    "OPEN — Phase 2 Target. Medium priority. "
    "Requires: Vendor API integration, procurement workflow automation spec. "
    "Responsible Agent: Rex (Group D, ≥97%). Target: Phase 2 Q2 2033.")
S49 += label_value("GAP-11 Spatial Analytics & Occupancy Intelligence",
    "OPEN — Phase 2 Target. Medium priority. "
    "Requires: IoT sensor integration spec, spatial analytics model. "
    "Responsible Agent: Bo (Group C, ≥94%). Target: Phase 2 Q3 2033.")
S49 += label_value("GAP-12 Multi-language Client Communication",
    "OPEN — Phase 2 Target. Medium priority. "
    "Requires: NLP model fine-tuning for Thai/EN/CN design terminology. "
    "Responsible Agent: Remy (Group B, ≥93%). Target: Phase 2 Q2 2033.")
S49 += body(
    "Phase 2 Gate Criteria: (1) Phase 1 Completion Certificate issued and SC-acknowledged, "
    "(2) WS-E Closure confirmed (Section 48/49), "
    "(3) Phase 2 Business Case submitted with budget estimate for 6 remaining HIGH GAPs, "
    "(4) SC Resolution SC-2032-XX authorising Phase 2 budget and timeline, "
    "(5) Phase 2 Programme Director nominated and onboarded."
)

S49 += heading2("49.6  รายการตรวจสอบปิดโครงการ (AMD4-CLOSE-01–05)")
S49 += label_value("AMD4-CLOSE-01",
    "All 5 Workstream Closure Reports received and accepted by SC — "
    "WS-A through WS-E formal closure confirmed. Target: Q2 2032.")
S49 += label_value("AMD4-CLOSE-02",
    "Phase 1 Completion Certificate issued — Coverage ≥68% verified by Atlas (KPI-WS-D-05), "
    "GAP-01/02/03/04/07/08 formal closure documented. Target: Q2 2032.")
S49 += label_value("AMD4-CLOSE-03",
    "Programme Financial Closure — all WS-A–E budgets reconciled, "
    "Contingency utilisation reported, final financial statement submitted to SC. Target: Q2 2032.")
S49 += label_value("AMD4-CLOSE-04",
    "Knowledge Transfer & Documentation — all SOP sections (S38–S49) accepted, "
    "Knowledge Base published (TH/EN), GitHub repository main branch tagged v2.5-Phase1-Complete. "
    "SHA reference: 14b90bc. Target: Q2 2032.")
S49 += label_value("AMD4-CLOSE-05",
    "Phase 2 Readiness Gate passed — Phase 2 Business Case approved by SC, "
    "SC-2032-XX resolution issued, Phase 2 Programme Director in post. Target: Q3 2032.")

S49 += heading2("49.7  AMD-004 Programme Timeline Summary")
S49 += body(
    "สรุปไทม์ไลน์รวมของโครงการ AMD-004 ตั้งแต่เริ่มต้นจนถึงการผ่าน Phase 2 Gate "
    "ครอบคลุม 10 ไตรมาส (Q3 2030 – Q3 2032)"
)
S49 += label_value("Q3–Q4 2030",
    "WS-A Corporate Governance (THB 0.8M) + WS-D Analytics & KPI Dashboard start (THB 0.9M). "
    "SC-2030-01 passed. GAP-08 closure work commenced.")
S49 += label_value("Q1–Q4 2031",
    "WS-B Technology Infrastructure (THB 1.1M, Q1–Q3). WS-C Client Service Innovation (THB 1.2M, Q2–Q4). "
    "GAP-05/06 infrastructure foundations laid.")
S49 += label_value("Q3–Q4 2030 (parallel)",
    "WS-D delivery: KPI framework KPI-001–024 built, Dashboard src/dashboard/ deployed, "
    "GAP-08 formally closed, Phase 1 Completion Certificate KPI-M4 issued.")
S49 += label_value("Q1–Q2 2032",
    "WS-E Human Capital & Change Management (THB 0.6M). "
    "TRN-001–004 delivered, CHG-001–004 executed, AMD4-CLOSE-01–05 completed.")
S49 += label_value("Q2 2032",
    "AMD-004 Programme formally closed. Phase 1 Completion Certificate SC-acknowledged. "
    "Coverage 68% confirmed. S38–S49 SOP package complete.")
S49 += label_value("Q3 2032 (target)",
    "Phase 2 Gate passed — SC-2032-XX resolution. Phase 2 programme commences "
    "targeting Coverage 80% by Q4 2033 (GAP-05/06/09/10/11/12).")

# ============================================================
# ASSEMBLE & INJECT
# ============================================================
NEW_CONTENT = S48 + S49

if '</w:body>' in xml:
    xml = xml.replace('</w:body>', NEW_CONTENT + '</w:body>', 1)
    print("Injection point: </w:body>")
else:
    raise ValueError("Cannot find </w:body> in document XML")

all_files['word/document.xml'] = xml.encode('utf-8')

with zipfile.ZipFile(DST, 'w', compression=zipfile.ZIP_DEFLATED) as zout:
    for name, data in all_files.items():
        zout.writestr(name, data)

# Verify
with zipfile.ZipFile(DST, 'r') as z:
    vxml = z.read('word/document.xml').decode('utf-8')
    ins_tags = re.findall(r'<w:ins[ >]', vxml)
    all_ids = re.findall(r'w:id="(\d+)"', vxml)
    s48 = 'WS-E Human Capital' in vxml and 'TRN-001' in vxml
    s49 = 'AMD4-CLOSE-01' in vxml and 'Phase 2 Gateway' in vxml
    inside_h = len(re.findall(r'<w:insideH', vxml))
    inside_v = len(re.findall(r'<w:insideV', vxml))

print(f"\n=== INJECTION RESULTS ===")
print(f"w:ins tracked insertions: {len(ins_tags)}")
print(f"Max ID used: {max(int(x) for x in all_ids) if all_ids else 0}")
print(f"w:insideH intact: {inside_h}")
print(f"w:insideV intact: {inside_v}")
print(f"S48 (WS-E Training) present: {s48}")
print(f"S49 (Programme Closure) present: {s49}")
print(f"File size: {os.path.getsize(DST):,} bytes")
print(f"IDs used: 959 – {_id - 1} (total {_id - 959} IDs allocated)")
