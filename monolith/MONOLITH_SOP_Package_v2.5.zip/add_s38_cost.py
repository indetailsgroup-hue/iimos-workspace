"""
Inject Section 38.8 – AMD-004 Cost Breakdown Framework (by WS × Category)
into monolith_project_summary_v25_accepted.docx as tracked insertions.
IDs start at 174 (max after S38 injection = 173).
"""
import zipfile, shutil, re, os

SRC  = "/home/sandbox/monolith_project_summary_v25_accepted.docx"
TEMP = "/home/sandbox/_add_s38_cost_tmp.docx"

AUTHOR = "Scispace Agent"
DATE   = "2026-09-03T00:00:00Z"
_id    = [174]

def nid():
    v = _id[0]; _id[0] += 1; return v

def esc(t):
    return (t.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
             .replace('"',"&quot;"))

def para_xml(runs_xml, spacing_before=0, spacing_after=100, ind_left=0):
    ppr_parts = []
    if spacing_before or spacing_after:
        ppr_parts.append(f'<w:spacing w:before="{spacing_before}" w:after="{spacing_after}"/>')
    if ind_left:
        ppr_parts.append(f'<w:ind w:left="{ind_left}"/>')
    ppr_parts.append(
        f'<w:rPr>'
        f'<w:ins w:id="{nid()}" w:author="{AUTHOR}" w:date="{DATE}"/>'
        f'</w:rPr>'
    )
    ppr = "<w:pPr>" + "".join(ppr_parts) + "</w:pPr>"
    ins_block = (
        f'<w:ins w:id="{nid()}" w:author="{AUTHOR}" w:date="{DATE}">'
        f'{runs_xml}'
        f'</w:ins>'
    )
    return f"<w:p>{ppr}{ins_block}</w:p>"

def run_xml(text, bold=False, size=24, color=None):
    rpr = "<w:rPr>"
    if bold: rpr += "<w:b/><w:bCs/>"
    rpr += f'<w:sz w:val="{size}"/><w:szCs w:val="{size}"/>'
    if color: rpr += f'<w:color w:val="{color}"/>'
    rpr += "</w:rPr>"
    return f'<w:r>{rpr}<w:t xml:space="preserve">{esc(text)}</w:t></w:r>'

def h2(text):
    return para_xml(run_xml(text, bold=True, size=28, color="2e75b6"),
                    spacing_before=200, spacing_after=80)

def body(text):
    return para_xml(run_xml(text, size=24), spacing_before=0, spacing_after=100)

def bullet(text):
    return para_xml(run_xml(text, size=24), spacing_before=0, spacing_after=80, ind_left=400)

def sub_bullet(text):
    return para_xml(run_xml(text, size=24), spacing_before=0, spacing_after=60, ind_left=720)

# ── Build cost breakdown paragraphs ──────────────────────────────────────────
paras = []

paras.append(h2("38.8 Budget Cost Breakdown Framework"))
paras.append(body(
    "The AMD-004 indicative budget of 5.2M THB is distributed across four cost categories "
    "for each workstream: Technology (infrastructure, licensing, platform build), "
    "Programme Management (project office, governance, documentation), "
    "Compliance (PDPA/GDPR, DPO review, audit, legal counsel), and "
    "Training (agent calibration, QA testing, staff capability). "
    "All figures are indicative and subject to SC-2030-01 ratification and detailed "
    "cost modelling during the Programme Mobilisation phase (PDD-005)."
))

# WS-A
paras.append(h2("38.8.1 WS-A Cost Breakdown — Agent Capability Enhancement Phase 2 (1.0M THB)"))
paras.append(bullet("Technology: 0.40M THB (40%) — LLM fine-tuning costs, model API licensing for up to 6 new agent profiles, integration API development, Group A-D capability testing environment"))
paras.append(bullet("Programme Management: 0.20M THB (20%) — Scoping and specification, project office coordination, delivery documentation, agent specification review cycles"))
paras.append(bullet("Compliance: 0.10M THB (10%) — Agent certification against GV2-P1 standards, SLA audit trails, S17 Group reclassification review"))
paras.append(bullet("Training: 0.30M THB (30%) — Agent calibration and onboarding (up to 6 new profiles), QA testing, SLA validation against Group A-D benchmarks, supervisor training"))

# WS-B
paras.append(h2("38.8.2 WS-B Cost Breakdown — Technology Infrastructure Next Generation (1.1M THB)"))
paras.append(bullet("Technology: 0.70M THB (64%) — Cloud infrastructure upgrade, vector-store v3 implementation (beyond INF-WS2-03), edge-compute hardware and licensing, LLM refresh platform costs"))
paras.append(bullet("Programme Management: 0.20M THB (18%) — Vendor management under GV2-P3 policy, infrastructure project governance, technical documentation and runbooks"))
paras.append(bullet("Compliance: 0.10M THB (9%) — Infrastructure security audit, penetration testing, cloud data residency compliance review (PDPA alignment)"))
paras.append(bullet("Training: 0.10M THB (9%) — IT operations team training on new infrastructure, edge-compute operations, runbook walkthroughs and incident response drills"))

# WS-C
paras.append(h2("38.8.3 WS-C Cost Breakdown — Client Service Innovation Delivery (1.2M THB)"))
paras.append(bullet("Technology: 0.40M THB (33%) — New service line platform build (up to 4 lines), client portal integration, API connectivity for Ember #23 and Shore #25 delivery workflows"))
paras.append(bullet("Programme Management: 0.25M THB (21%) — Client coordination, delivery management, service line go-live planning, stakeholder communication"))
paras.append(bullet("Compliance: 0.35M THB (29%) — PDPA/GDPR DPO review per service line (mandatory), data processing agreements, legal counsel for new client-facing services, ongoing compliance monitoring"))
paras.append(bullet("Training: 0.20M THB (17%) — Ember #23 and Shore #25 service-specific training, client onboarding materials, internal helpdesk training for new service lines"))

# WS-D
paras.append(h2("38.8.4 WS-D Cost Breakdown — Data & Analytics Maturity Enhancement (0.9M THB)"))
paras.append(bullet("Technology: 0.50M THB (56%) — Analytics data warehouse expansion to enterprise Level 3, predictive analytics model development, automated client reporting v2.0 platform build"))
paras.append(bullet("Programme Management: 0.15M THB (17%) — Data governance framework, analytics project documentation, cross-workstream data integration coordination"))
paras.append(bullet("Compliance: 0.10M THB (11%) — Data privacy impact assessment for analytics outputs, audit trails for automated SC reports (ANL-WS3-05 extension), PDPA data retention review"))
paras.append(bullet("Training: 0.15M THB (17%) — Analytics platform end-user training (all 34 agents), report interpretation training for supervisors, client-facing analytics briefing materials"))

# WS-E
paras.append(h2("38.8.5 WS-E Cost Breakdown — Governance Continuity & Compliance (1.0M THB)"))
paras.append(bullet("Technology: 0.10M THB (10%) — Governance policy management platform, compliance monitoring tooling, SC agenda and documentation systems"))
paras.append(bullet("Programme Management: 0.30M THB (30%) — Programme governance office (concurrent with all WS-A to WS-D), SC Charter maintenance (Section 23), AMD-004 programme reporting to SC"))
paras.append(bullet("Compliance: 0.50M THB (50%) — Dedicated DPO function establishment, PDPA/GDPR embedded compliance programme (full AMD-004 lifecycle), legal counsel retainer, annual external audit, regulatory change monitoring"))
paras.append(bullet("Training: 0.10M THB (10%) — Governance training for Programme Office, compliance workshops for all workstream leads, DPO capability building"))

# Summary
paras.append(h2("38.8.6 AMD-004 Cost Category Summary"))
paras.append(body(
    "Aggregated across all five workstreams (WS-A to WS-E), the 5.2M THB indicative envelope "
    "distributes across cost categories as follows. Technology represents the largest single "
    "category, reflecting the infrastructure and platform investment required for Phase E. "
    "Compliance is elevated compared to AMD-003 due to the PDPA/GDPR embedded programme "
    "running concurrently across all workstreams under WS-E."
))
paras.append(bullet("Technology: 2.10M THB (40%) — Infrastructure, LLM, platform, licensing"))
paras.append(bullet("Programme Management: 1.10M THB (21%) — Project office, governance, documentation"))
paras.append(bullet("Compliance: 1.15M THB (22%) — PDPA/GDPR, DPO, legal, audit (elevated — WS-E concurrent)"))
paras.append(bullet("Training: 0.85M THB (16%) — Calibration, QA, onboarding, capability building"))
paras.append(bullet("TOTAL AMD-004 INDICATIVE: 5.20M THB — Subject to SC-2030-01 ratification (Q3 2030)"))
paras.append(body(
    "Note: Contingency reserve allocation to be confirmed per GV2-P1 budget governance rules "
    "following SC-2030-01 approval. Annual phasing: FY2031 (1.8M THB), FY2032 (1.9M THB), "
    "FY2033 (1.5M THB). Detailed cost modelling to be completed during PDD-005 Programme "
    "Mobilisation phase."
))

print(f"Total paragraphs: {len(paras)}")

# ── Inject ────────────────────────────────────────────────────────────────────
with zipfile.ZipFile(SRC, 'r') as zin:
    xml = zin.read("word/document.xml").decode("utf-8")

print(f"document.xml before: {len(xml):,} chars")

injection = "\n".join(paras)
pattern = r'(<w:sectPr[ >])'
if not re.search(pattern, xml):
    raise RuntimeError("Cannot find <w:sectPr> injection point")

xml = re.sub(pattern, injection + r'\n\1', xml, count=1)
print(f"document.xml after:  {len(xml):,} chars")

ins_count = len(re.findall(r'<w:ins[ >]', xml))
del_count = len(re.findall(r'<w:del[ >]', xml))
print(f"w:ins={ins_count}, w:del={del_count}, new paragraphs={len(paras)}")

with zipfile.ZipFile(SRC, 'r') as zin:
    with zipfile.ZipFile(TEMP, 'w', compression=zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            if item.filename == "word/document.xml":
                zout.writestr(item, xml.encode("utf-8"))
            else:
                zout.writestr(item, zin.read(item.filename))

shutil.copy(TEMP, SRC)
os.remove(TEMP)

final_size = os.path.getsize(SRC)
print(f"Output: {SRC} ({final_size:,} bytes)")

with zipfile.ZipFile(SRC, 'r') as z:
    body_xml = z.read("word/document.xml").decode("utf-8")

checks = [
    ("S38 AMD-004 present",      "AMD-004" in body_xml),
    ("Cost breakdown present",   "38.8" in body_xml),
    ("WS-A breakdown",           "WS-A Cost Breakdown" in body_xml),
    ("WS-E breakdown",           "WS-E Cost Breakdown" in body_xml),
    ("Category summary",         "38.8.6" in body_xml),
    ("Total 5.20M",              "5.20M THB" in body_xml),
    ("w:ins tracked",            ins_count > 0),
    ("No w:del",                 del_count == 0),
]

print("\nSpot checks:")
all_pass = True
for label, result in checks:
    status = "OK" if result else "FAIL"
    if not result: all_pass = False
    print(f"  [{status}] {label}")

print(f"\nMax w:id used = {_id[0] - 1}")
print("\n" + ("=== PASS ===" if all_pass else "=== FAIL ==="))
