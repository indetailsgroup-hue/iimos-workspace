# MONOLITH / DAPH Decor AI Agent System — v3.0 Planning
**Scope: Post-Q1 2027 | Talent + Ops Live | Next Agent Phase**
*Prepared: September 2026 · Status: Planning*

---

## 1. Executive Overview

v3.0 marks the transition from the **Deployment Phase** to the **Optimization & Expansion Phase** of the MONOLITH AI Agent System. With all 20 active agents operational and all 6 Roadmap agents deployed by Q1 2027 (Nexus, Compass, Scout, Guardian, Talent, Ops), v3.0 focuses on:

- Full live operation of **Talent** (HR Manager AI) and **Ops** (GM/MD AI Orchestrator)
- Cross-agent orchestration and inter-department intelligence flows
- Coverage expansion to address remaining gap positions (18 unmapped out of 38)
- Agent performance optimization based on v2.5 KPI baselines
- Advanced analytics, SOP automation, and client-facing AI integrations

---

## 2. v3.0 Trigger Conditions

v3.0 planning activates when **all** of the following are confirmed:

| Condition | Target Date | Status |
|-----------|-------------|--------|
| Talent Agent live (HR full deployment) | Q1 2027 | Planned |
| Ops Agent live (GM/MD orchestration) | Q1 2027 | Planned |
| All 6 Roadmap agents stable ≥ 30 days | Q2 2027 | TBD |
| v2.8 deliverables accepted and archived | Q3 2026 | In progress |
| 90-day performance review of Nexus + Compass | Q1 2027 | TBD |

---

## 3. Phase Breakdown

### Phase A — Stabilization (Q1–Q2 2027)

**Goal:** Ensure all 20 agents are running at target KPI thresholds before expansion.

**Key actions:**
- Run 90-day post-deployment review for Nexus (Project Tracking) and Compass (Sales CRM)
- Conduct 60-day review for Scout (Marketing) and Guardian (QA) after their Q4 2026 launch
- Baseline all 20 agents' response times, accuracy rates, and escalation frequencies
- Resolve any integration gaps between AI agents and existing DAPH Decor systems
- Update SOP Manual (S1–S15) to reflect live operational procedures

**Deliverables:**
- `performance_review_v30_phase_a.docx` — 90-day KPI report
- `agent_integration_audit.xlsx` — per-agent system connection status
- Updated `changelog_v25.md` → renamed `changelog_v30.md`

---

### Phase B — Gap Coverage (Q2–Q3 2027)

**Goal:** Reduce the 18 unmapped positions (currently without AI coverage) by at least 50%.

**Current gap analysis (from v2.5):**
- 20 agents cover 20 of 38 positions = **47% coverage**
- 18 positions remain without dedicated AI agent assignment
- Highest-gap departments: SITE (Site Operations), PRO (Procurement), ADM (Administration)

**Agent candidates for v3.0 expansion (provisional names):**

| # | Name | Role | Target Dept | Priority |
|---|------|------|-------------|----------|
| 21 | **Vega** | Site Safety & Compliance AI | SITE / QA | P0 |
| 22 | **Stone** | Materials & Inventory Intelligence | PRO / OPS | P1 |
| 23 | **Ember** | Client Design Brief Automation | DS / CRM | P1 |
| 24 | **Pulse** | Real-Time KPI Dashboard AI | OPS / GM | P2 |
| 25 | **Shore** | Post-Installation Support AI | SITE / CRM | P2 |

**Note:** Agent names and roles are provisional and subject to DAPH leadership approval.

---

### Phase C — Advanced Orchestration (Q3–Q4 2027)

**Goal:** Enable cross-agent intelligence — agents sharing context and triggering each other based on workflow events.

**Key orchestration flows planned:**

1. **Sales → Design → Production Pipeline**
   Compass (Sales) → Kelly (Design Lead) → Forge (Procurement) → Atlas (Project Mgmt)
   Trigger: New client project confirmed → automated handoff chain

2. **QA → Site → Delivery Chain**
   Guardian (QA) → Bo (Site Ops) → Aria (Client Relations)
   Trigger: QC milestone passed → auto-notify client and schedule delivery

3. **HR → Operations Loop**
   Talent (HR) → Ops (GM/MD) → Core (Systems)
   Trigger: Headcount change → capacity recalculation → system update

4. **Marketing → CRM → Sales Intelligence**
   Scout (Marketing) → Remy (CRM) → Compass (Sales)
   Trigger: Campaign launched → lead scoring update → sales prioritization

**Technical requirements:**
- Shared event bus / message queue between agents
- Standardized inter-agent communication protocol (JSON schema v1.0)
- Ops agent as central orchestrator / supervisor
- Audit logging for all cross-agent triggers

---

## 4. SOP Manual Updates (v3.0)

The following new sections are planned for the SOP Manual:

| Section | Title | Scope |
|---------|-------|-------|
| S16 | Cross-Agent Orchestration Protocol | v3.0 agent pipeline flows |
| S17 | AI Performance Review Framework | 30/60/90-day KPI reviews |
| S18 | Gap Coverage Expansion Plan | v3.0 new agent onboarding |
| S19 | Client AI Integration Standards | Client-facing AI touchpoints |
| S20 | Data Governance & AI Ethics | Data handling, privacy, compliance |

---

## 5. Package & Documentation Plan

**v3.0 deliverables (tentative):**

- `MONOLITH_SOP_Package_v3.0.zip` — updated full package (est. 25+ files)
- `monolith_project_summary_v30.docx` — S1–S20 project summary
- `ai_agent_dashboard_v30.html` — updated interactive dashboard (25 agents)
- `ai_agent_dashboard_presentation_v30.pptx` — updated English deck
- `ai_agent_dashboard_thai_v30.pptx` — updated Thai deck
- `performance_review_v30.pdf` — 90-day deployment review
- `v30_changelog.md` — all changes from v2.8 to v3.0

---

## 6. Timeline Summary

```
Q1 2027:  Talent + Ops go live → v3.0 Phase A begins
Q2 2027:  90-day reviews complete → Phase B gap coverage planning
Q3 2027:  v3.0 Phase B agents deployed (Vega, Stone, Ember)
Q4 2027:  Cross-agent orchestration Phase C activated
Q1 2028:  v3.0 full stabilization → v3.1 planning begins
```

---

## 7. Risks & Mitigations

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Talent/Ops deployment delayed past Q1 2027 | Medium | High | Begin Phase A readiness prep in Q4 2026 |
| Cross-agent orchestration complexity | High | High | Start with 1 pipeline (Sales→Design) before full rollout |
| Data silos between departments | Medium | Medium | Standardize data schemas in Q2 2027 |
| Agent performance below baseline KPIs | Low | High | Set 80% KPI threshold as go/no-go gate for Phase B |
| User adoption resistance | Medium | Medium | Run training quizzes + onboarding sessions per team |

---

## 8. Sign-off

This v3.0 Planning document is subject to review and approval by DAPH Decor leadership before formal project initiation.

**Prepared by:** Scispace Agent — MONOLITH AI System v2.8
**Date:** September 2026
**Next review:** Upon Talent + Ops go-live (Q1 2027)

---

*MONOLITH / DAPH Decor · AI Agent Dashboard v2.5 → v3.0 · Confidential · เอกสารลับ*
