"""
accept_s38.py — XML-strip accept all tracked changes in
monolith_project_summary_v25_accepted.docx (S1–S38 full accept).
Produces clean 38-section final version in place.
Backup saved as monolith_project_summary_v25_accepted_s38_tracked.docx
"""
import zipfile, re, shutil, os

SRC = '/home/sandbox/monolith_project_summary_v25_accepted.docx'
BCK = '/home/sandbox/monolith_project_summary_v25_accepted_s38_tracked.docx'

# Backup
shutil.copy(SRC, BCK)
print(f'Backup: {BCK} ({os.path.getsize(BCK):,} bytes)')

with zipfile.ZipFile(SRC, 'r') as z:
    names = z.namelist()
    files = {n: z.read(n) for n in names}

xml = files['word/document.xml'].decode('utf-8')
before_ins = len(re.findall(r'<w:ins[ >]', xml))
before_del = len(re.findall(r'<w:del[ >]', xml))
print(f'Before: w:ins={before_ins} w:del={before_del} chars={len(xml):,}')

# 1. Remove <w:del ...>...</w:del> blocks (deleted content — discard)
xml = re.sub(r'<w:del\b[^>]*>.*?</w:del>', '', xml, flags=re.DOTALL)

# 2. Unwrap <w:ins ...>...</w:ins> — keep inner content, remove wrapper tags
xml = re.sub(r'<w:ins\b[^>]*/>', '', xml)  # self-closing ins tags
xml = re.sub(r'<w:ins\b[^>]*>', '', xml)
xml = re.sub(r'</w:ins>', '', xml)

# 3. Remove <w:rPrChange>...</w:rPrChange> revision property change markers
xml = re.sub(r'<w:rPrChange\b[^>]*>.*?</w:rPrChange>', '', xml, flags=re.DOTALL)

# 4. Remove <w:pPrChange>...</w:pPrChange> paragraph property change markers
xml = re.sub(r'<w:pPrChange\b[^>]*>.*?</w:pPrChange>', '', xml, flags=re.DOTALL)

after_ins = len(re.findall(r'<w:ins[ >]', xml))
after_del = len(re.findall(r'<w:del[ >]', xml))
print(f'After:  w:ins={after_ins} w:del={after_del} chars={len(xml):,}')

files['word/document.xml'] = xml.encode('utf-8')

with zipfile.ZipFile(SRC, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for name in names:
        z.writestr(name, files[name])

final_size = os.path.getsize(SRC)
print(f'Output: {SRC} ({final_size:,} bytes)')

# Spot checks
checks = [
    ('S38 AMD-004 present',      'AMD-004 Programme Definition Document'),
    ('Cost breakdown present',   'Cost Breakdown Template'),
    ('WS-A cost present',        'WS-A Agent Capability Enhancement'),
    ('WS-E cost present',        'WS-E Governance Continuity'),
    ('Total 5.20M present',      '5.20M'),
    ('No w:ins remaining',       None),
    ('No w:del remaining',       None),
]
all_ok = True
for label, term in checks:
    if term is None:
        if label.startswith('No w:ins'):
            ok = after_ins == 0
        else:
            ok = after_del == 0
    else:
        ok = term in xml
    status = 'OK' if ok else 'FAIL'
    if not ok:
        all_ok = False
    print(f'  [{status}] {label}')

print()
if all_ok and after_ins == 0 and after_del == 0:
    print('=== PASS ===')
else:
    print('=== FAIL — check above ===')
