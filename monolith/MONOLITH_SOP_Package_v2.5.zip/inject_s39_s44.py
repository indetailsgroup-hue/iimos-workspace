"""
inject_s39_s44.py
Inject Sections S39–S44 into monolith_project_summary_v25_accepted.docx
Covers: Pillar 1 Biophilic (GAP-01), Pillar 2 Design Freeze Gate (GAP-02),
        Pillar 6 Sensory Commissioning (GAP-03), Pillar 6 POE (GAP-04),
        SC Governance Module (GAP-07), 28-Agent Code Governance (GAP-05/08)
"""
import zipfile, re, shutil, os

SRC = '/home/sandbox/monolith_project_summary_v25_accepted.docx'
DST = '/home/sandbox/monolith_project_summary_v25_accepted.docx'
BAK = '/home/sandbox/monolith_project_summary_v25_accepted_pre_s39_backup.docx'

shutil.copy(SRC, BAK)
print(f'Backup: {BAK}')

with zipfile.ZipFile(SRC, 'r') as z:
    xml = z.read('word/document.xml').decode('utf-8')
    all_files = {name: z.read(name) for name in z.namelist()}

# ---- ID counter ----
existing_ids = [int(x) for x in re.findall(r'w:id="(\d+)"', xml)]
_id = max(existing_ids) + 1 if existing_ids else 10

def nid():
    global _id
    v = _id
    _id += 1
    return v

AUTHOR = "Scispace Agent"
DATE   = "2026-09-03T00:00:00Z"

def heading1(text):
    """Bold navy section heading (36pt)"""
    pi, ri = nid(), nid()
    return (
        f'<w:p><w:pPr><w:spacing w:before="320" w:after="100"/>'
        f'<w:rPr><w:ins w:id="{pi}" w:author="{AUTHOR}" w:date="{DATE}"/></w:rPr></w:pPr>'
        f'<w:ins w:id="{ri}" w:author="{AUTHOR}" w:date="{DATE}">'
        f'<w:r><w:rPr><w:b/><w:bCs/><w:sz w:val="36"/><w:szCs w:val="36"/>'
        f'<w:color w:val="1f2d5a"/></w:rPr>'
        f'<w:t xml:space="preserve">{text}</w:t></w:r></w:ins></w:p>\n'
    )

def heading2(text):
    """Blue subsection heading (28pt)"""
    pi, ri = nid(), nid()
    return (
        f'<w:p><w:pPr><w:spacing w:before="200" w:after="80"/>'
        f'<w:rPr><w:ins w:id="{pi}" w:author="{AUTHOR}" w:date="{DATE}"/></w:rPr></w:pPr>'
        f'<w:ins w:id="{ri}" w:author="{AUTHOR}" w:date="{DATE}">'
        f'<w:r><w:rPr><w:b/><w:bCs/><w:sz w:val="28"/><w:szCs w:val="28"/>'
        f'<w:color w:val="2e75b6"/></w:rPr>'
        f'<w:t xml:space="preserve">{text}</w:t></w:r></w:ins></w:p>\n'
    )

def body(text, indent=400):
    """Normal body paragraph (24pt)"""
    pi, ri = nid(), nid()
    return (
        f'<w:p><w:pPr><w:spacing w:before="0" w:after="80"/>'
        f'<w:ind w:left="{indent}"/>'
        f'<w:rPr><w:ins w:id="{pi}" w:author="{AUTHOR}" w:date="{DATE}"/></w:rPr></w:pPr>'
        f'<w:ins w:id="{ri}" w:author="{AUTHOR}" w:date="{DATE}">'
        f'<w:r><w:rPr><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>'
        f'<w:t xml:space="preserve">{text}</w:t></w:r></w:ins></w:p>\n'
    )

def bullet(text):
    """Bullet-style indented paragraph"""
    pi, ri = nid(), nid()
    return (
        f'<w:p><w:pPr><w:spacing w:before="0" w:after="60"/>'
        f'<w:ind w:left="600" w:hanging="200"/>'
        f'<w:rPr><w:ins w:id="{pi}" w:author="{AUTHOR}" w:date="{DATE}"/></w:rPr></w:pPr>'
        f'<w:ins w:id="{ri}" w:author="{AUTHOR}" w:date="{DATE}">'
        f'<w:r><w:rPr><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr>'
        f'<w:t xml:space="preserve">• {text}</w:t></w:r></w:ins></w:p>\n'
    )

def label_value(label, value):
    """Label: value line (label bold)"""
    pi, r1, r2 = nid(), nid(), nid()
    return (
        f'<w:p><w:pPr><w:spacing w:before="0" w:after="60"/>'
        f'<w:ind w:left="600"/>'
        f'<w:rPr><w:ins w:id="{pi}" w:author="{AUTHOR}" w:date="{DATE}"/></w:rPr></w:pPr>'
        f'<w:ins w:id="{r1}" w:author="{AUTHOR}" w:date="{DATE}">'
        f'<w:r><w:rPr><w:b/><w:bCs/><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr>'
        f'<w:t xml:space="preserve">{label}:  </w:t></w:r></w:ins>'
        f'<w:ins w:id="{r2}" w:author="{AUTHOR}" w:date="{DATE}">'
        f'<w:r><w:rPr><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr>'
        f'<w:t xml:space="preserve">{value}</w:t></w:r></w:ins></w:p>\n'
    )

# ============================================================
# SECTION 39 — Pillar 1: Biophilic Design & WELL/LEED
# ============================================================
S39 = ""
S39 += heading1("39. Pillar 1 — Biophilic Design Framework & WELL/LEED Compliance (GAP-01)")
S39 += heading2("39.1  Overview")
S39 += body("Section 39 establishes the Biophilic Design Framework and WELL/LEED Compliance Layer for DAPH Decor projects. "
            "This section closes GAP-01 identified in the SOP-GitHub Coverage Analysis (September 2026), where no corresponding "
            "implementation existed in the monolith-workspace repository for biophilic material certification, WELL v2 feature tracking, "
            "or LEED v4 credit management. This framework defines the standard operating procedures, agent responsibilities, and "
            "GitHub module specification (src/biophilic/) required to achieve World-Class biophilic design delivery.")
S39 += body("Scope: All DAPH Decor interior design projects with contract value ≥ THB 2.0M or client specifications requiring WELL/LEED certification. "
            "Responsible Agents: Aria (Design Automation), Nova (SLA Group A — ≥95% accuracy threshold).")

S39 += heading2("39.2  WELL v2 Feature Integration")
S39 += body("DAPH Decor projects shall reference the following WELL v2 Building Standard feature categories as mandatory design inputs "
            "for luxury interior fit-out projects:")
S39 += label_value("Air (A01-A09)", "Low-VOC materials specification, ventilation rate compliance, air filtration standards for FF&E materials")
S39 += label_value("Light (L01-L07)", "Circadian lighting design, visual comfort, daylight access simulation in BIM — coordinated with BIM module (S20)")
S39 += label_value("Mind (M01-M13)", "Biophilic design elements, restorative spaces, nature connection features integrated in design brief (S3)")
S39 += label_value("Materials (X01-X06)", "Material transparency documentation — Red List avoidance, DECLARE label preferred, cross-referenced furniture-hardware-vault")
S39 += label_value("Thermal (T01-T04)", "Thermal comfort zone compliance per ASHRAE 55; seasonal variation documented in Sensory Commissioning (S41)")
S39 += label_value("Sound (S01-S04)", "Acoustic performance targets (WELL STC ratings), coordinated with Sensory Commissioning benchmark table (S41.2)")

S39 += heading2("39.3  Biophilic Design Principles — 14 Patterns")
S39 += body("Design briefs for qualifying projects shall incorporate a minimum of 6 of the 14 recognised biophilic design patterns:")
S39 += bullet("Pattern 01: Visual Connection with Nature — windows, green walls, water features, natural views")
S39 += bullet("Pattern 02: Non-Visual Connection with Nature — sensory stimuli (air, sound, temperature variation)")
S39 += bullet("Pattern 03: Non-Rhythmic Sensory Stimuli — spontaneous/unpredictable nature movements (water, fire, wind)")
S39 += bullet("Pattern 04: Thermal & Airflow Variability — slight variations in air temperature and airflow")
S39 += bullet("Pattern 05: Presence of Water — sight/sound/touch of water features in public areas")
S39 += bullet("Pattern 06: Dynamic & Diffuse Light — natural light variation, shadow movement across surfaces")
S39 += bullet("Pattern 07: Connection with Natural Systems — seasonal change, biological rhythms visible in design")
S39 += bullet("Pattern 08: Biomorphic Forms & Patterns — organic shapes, fibonacci patterns in surface design")
S39 += bullet("Pattern 09: Material Connection with Nature — stone, wood, bamboo, natural textiles, unprocessed textures")
S39 += bullet("Pattern 10: Complexity & Order — natural fractal geometry applied to millwork and ceiling patterns")
S39 += bullet("Pattern 11: Prospect — elevated vantage points, clear sightlines, spatial openness")
S39 += bullet("Pattern 12: Refuge — sheltered spaces for retreat, canopy elements, enveloping materials")
S39 += bullet("Pattern 13: Mystery — layered spaces, partial obscurement, discovery sequence in circulation")
S39 += bullet("Pattern 14: Awe — use of scale, natural phenomena, transcendent design moments")

S39 += heading2("39.4  LEED v4 Credit Categories — Interior Design & Construction (ID+C)")
S39 += body("For projects targeting LEED v4 ID+C certification (Hospitality, Commercial Interiors, or Retail), "
            "the following credit categories are applicable:")
S39 += label_value("Location & Transportation (LT)", "Access to public transit, bicycle facilities — typically preconditioned by building selection")
S39 += label_value("Sustainable Sites (SS)", "Construction activity pollution prevention, site assessment for interior renovation")
S39 += label_value("Water Efficiency (WE)", "Indoor water use reduction — low-flow fixtures mandatory for qualifying projects")
S39 += label_value("Energy & Atmosphere (EA)", "Lighting power density, HVAC coordination with building systems, energy sub-metering")
S39 += label_value("Materials & Resources (MR)", "Building product disclosure (EPD), material ingredient reporting, waste management — cross-ref furniture-hardware-vault")
S39 += label_value("Indoor Environmental Quality (IEQ)", "Low-emitting materials (adhesives, sealants, flooring, composite wood), acoustic performance, lighting control")
S39 += label_value("Innovation (IN)", "Innovative design strategies beyond LEED baseline — biophilic design earns IN credit")

S39 += heading2("39.5  Biophilic & WELL/LEED Implementation Checklist")
S39 += label_value("BIO-CHK-01", "Design brief includes minimum 6 biophilic patterns documented — completed by Aria at Design Phase (S3)")
S39 += label_value("BIO-CHK-02", "Material specification cross-referenced against WELL X01-X06 material transparency requirements")
S39 += label_value("BIO-CHK-03", "furniture-hardware-vault entries tagged with WELL/LEED compliance level (BIO-01 / BIO-02 / BIO-03)")
S39 += label_value("BIO-CHK-04", "LEED scorecard populated at design freeze (Gate 2 — see S40) with target credit count confirmed")
S39 += label_value("BIO-CHK-05", "VOC testing specification included in material procurement brief for finishes and adhesives")
S39 += label_value("BIO-CHK-06", "Sensory commissioning benchmarks (S41) aligned with WELL Air and Sound feature targets")
S39 += label_value("BIO-CHK-07", "Post-occupancy WELL feature compliance verified at 6-month POE (S42)")

S39 += heading2("39.6  Agent Responsibilities")
S39 += label_value("Aria (Design Automation)", "Generates biophilic pattern specification, WELL material matrix, LEED scorecard at design stage")
S39 += label_value("Nova (Compliance)", "Validates WELL/LEED documentation completeness, issues compliance flag if BIO-CHK checklist incomplete")
S39 += label_value("Rex (Vendor/Procurement)", "Ensures furniture-hardware-vault suppliers maintain WELL/LEED material certification on file")
S39 += label_value("Pulse (Analytics)", "Tracks biophilic pattern compliance rate per project; quarterly WELL/LEED scorecard report to SC")

S39 += heading2("39.7  GitHub Module Specification: src/biophilic/")
S39 += body("AMD-004 WS-A shall commission the development of src/biophilic/ module with the following sub-modules:")
S39 += bullet("src/biophilic/well-checklist/ — WELL v2 feature tracking, project-level compliance status")
S39 += bullet("src/biophilic/pattern-matrix/ — 14-pattern selection interface, design brief integration")
S39 += bullet("src/biophilic/leed-scorecard/ — LEED ID+C credit tracking, target vs actual scoring")
S39 += bullet("src/biophilic/material-tagger/ — furniture-hardware-vault WELL/LEED tag management")
S39 += bullet("src/biophilic/compliance-report/ — automated WELL/LEED progress report generator")

S39 += heading2("39.8  S39 Milestones")
S39 += label_value("S39-M1", "Biophilic Design SOP published and incorporated in designer onboarding (Q1 2031)")
S39 += label_value("S39-M2", "furniture-hardware-vault fully tagged with WELL/LEED compliance levels (Q2 2031)")
S39 += label_value("S39-M3", "src/biophilic/ module development complete and integrated with src/designer/ (Q3 2031)")
S39 += label_value("S39-M4", "First WELL-certified DAPH Decor project completed and submitted to SC (Q4 2031)")

# ============================================================
# SECTION 40 — Pillar 2: Design Freeze Gate System
# ============================================================
S40 = ""
S40 += heading1("40. Pillar 2 — Design Freeze Gate System (GAP-02)")
S40 += heading2("40.1  Overview")
S40 += body("Section 40 establishes the Design Freeze Gate System for DAPH Decor, closing GAP-02 identified in the SOP-GitHub "
            "Coverage Analysis. The src/gate/ module in monolith-workspace contains rule engine scaffolding (builders, compute, "
            "rules, ui, utils) but lacks a formal Design Freeze workflow with sequential client approval chains, milestone locks, "
            "and freeze-violation alerts. This section defines the four-gate framework, approval authority matrix, violation protocol, "
            "and GitHub extension specification for src/gate/.")
S40 += body("Scope: All DAPH Decor projects from design concept through manufacturing release. "
            "Responsible Agents: Kelly (Project & Operations Coordinator, Group A ≥95%), Atlas (QC Gate Monitoring, Group C ≥94%).")

S40 += heading2("40.2  Design Freeze Gate Framework")
S40 += body("The Design Freeze Gate System comprises four sequential gates. No gate may be bypassed without SC Programme Director authorisation.")
S40 += label_value("Gate 0 — Concept Lock (G0)", "Design concept confirmed with client; mood board, space planning, material palette approved. Trigger: signed concept approval form. Agent: Aria generates; Kelly tracks.")
S40 += label_value("Gate 1 — Schematic Design Freeze (G1)", "Floor plans, elevations, and 3D visualisations frozen. All biophilic patterns (S39) confirmed. Client sign-off required within 5 business days. Agent: Compass (Design PM).")
S40 += label_value("Gate 2 — Design Development Freeze (G2)", "Detailed drawings, material specifications, FF&E schedule, LEED scorecard (S39.4) confirmed. All furniture-hardware-vault items specified. No substitution post-G2 without Change Request (CR). Agent: Kelly + Atlas.")
S40 += label_value("Gate 3 — Construction Document Release (G3)", "Final working drawings released to factory/CNC. Triggers AMD-004 manufacturing pipeline (src/cnc/). Irreversible without formal CR + SC notification. Agent: Blaze (D2M Release).")

S40 += heading2("40.3  Approval Authority Matrix")
S40 += body("Each gate requires the following approvals before lock:")
S40 += label_value("G0 Approvers", "Lead Designer + Client Representative (mandatory)")
S40 += label_value("G1 Approvers", "Design Director + Client Representative + Project Manager")
S40 += label_value("G2 Approvers", "Design Director + Procurement Manager + Client Representative + Quality Assurance (Atlas)")
S40 += label_value("G3 Approvers", "Programme Director + Factory Manager + Client Representative — SC notification required within 24 hours")

S40 += heading2("40.4  Freeze Violation Protocol")
S40 += body("A Design Freeze Violation (DFV) is triggered when any design element is modified post-gate-lock without an approved Change Request.")
S40 += label_value("DFV-Level 1 (Minor)", "Material substitution, finish colour change — CR required within 24h; Kelly notified")
S40 += label_value("DFV-Level 2 (Significant)", "Dimension change, furniture substitution — CR + client re-approval + Gate re-validation within 48h")
S40 += label_value("DFV-Level 3 (Critical)", "Structural/layout change post-G2 — Full Gate 2 re-run, SC Programme Director notification, potential project delay escalation")
S40 += label_value("Change Request (CR) Process", "CR-FORM-001 submitted via Field App or LINE OA; Atlas validates; Programme Director approves; factory notified")

S40 += heading2("40.5  Agent Responsibilities")
S40 += label_value("Kelly (Group A)", "Overall gate timeline management, client communication, CR tracking, DFV escalation to SC")
S40 += label_value("Compass (Group B)", "Design stage scheduling, gate milestone tracking, designer deadline coordination")
S40 += label_value("Atlas (Group C)", "Gate 2 quality verification, post-G2 drawing compliance check, DFV detection")
S40 += label_value("Blaze (Group A)", "Gate 3 CNC release validation, manufacturing package completeness check before src/cnc/ trigger")

S40 += heading2("40.6  GitHub Extension Specification: src/gate/")
S40 += body("AMD-004 WS-A shall extend src/gate/ with the following components:")
S40 += bullet("src/gate/freeze-workflow/ — G0/G1/G2/G3 sequential state machine with client notification triggers")
S40 += bullet("src/gate/cr-management/ — Change Request CRUD, approval chain, version history")
S40 += bullet("src/gate/dfv-detector/ — Real-time DFV alerting integrated with src/workflow/approval/")
S40 += bullet("src/gate/milestone-lock/ — Immutable gate lock records in Supabase (audit trail for ISO 9001)")
S40 += bullet("src/gate/client-portal-integration/ — Client sign-off interface via supabase/functions/customer-design-view/")

S40 += heading2("40.7  S40 Milestones")
S40 += label_value("S40-M1", "Gate 0 and Gate 1 workflows live in src/gate/ — first client pilot project (Q1 2031)")
S40 += label_value("S40-M2", "Gate 2 full approval chain with DFV alerting operational (Q2 2031)")
S40 += label_value("S40-M3", "Gate 3 CNC release integration with src/cnc/ complete (Q3 2031)")
S40 += label_value("S40-M4", "DFV rate KPI established — target ≤2 DFV-Level 2+ events per 10 projects (Q4 2031)")

# ============================================================
# SECTION 41 — Pillar 6a: Sensory Commissioning Protocol
# ============================================================
S41 = ""
S41 += heading1("41. Pillar 6a — Sensory Commissioning Protocol (GAP-03)")
S41 += heading2("41.1  Overview")
S41 += body("Section 41 establishes the Sensory Commissioning Protocol, closing GAP-03. Sensory Commissioning is the systematic "
            "verification that a completed interior environment meets defined acoustic, lighting, thermal, air quality, and "
            "tactile benchmarks before client handover. This process is distinct from construction QC (S7) and operates post-installation "
            "as the final experiential acceptance test. The packages/field-app/ captures general QC; this section adds the sensory "
            "benchmark layer, commissioning test procedures, and acceptance sign-off framework.")
S41 += body("Scope: All DAPH Decor projects. Phased commissioning required for projects > THB 3.0M. "
            "Responsible Agents: Shore (QC Field, Group B ≥93%), Hana (Environmental QC, Group B ≥93%).")

S41 += heading2("41.2  Sensory Benchmark Standards")
S41 += body("The following benchmark standards apply to all commissioned DAPH Decor spaces:")
S41 += label_value("Acoustic (SB-A)", "Background noise level ≤ NC-35 (living/dining) or ≤ NC-30 (bedroom/study). Reverberation time RT60 ≤ 0.5s for spaces ≤ 50m2. STC ≥ 45 for party walls.")
S41 += label_value("Lighting (SB-L)", "Task area illuminance: 300–500 lux (kitchen), 100–300 lux (living), 50–100 lux (bedroom ambient). Colour rendering CRI ≥ 90. CCT per design intent ±200K. UGR ≤ 19 for all direct luminaires.")
S41 += label_value("Thermal (SB-T)", "Operative temperature: 23–26°C (cooling season), 20–23°C (heating season). Radiant temperature asymmetry ≤ 5°C. Relative humidity: 40–60%.")
S41 += label_value("Air Quality (SB-Q)", "CO2 ≤ 1000 ppm in occupied spaces. TVOC ≤ 500 μg/m3 (new installation 30-day post-install). PM2.5 ≤ 12 μg/m3. Formaldehyde ≤ 0.1 ppm.")
S41 += label_value("Tactile/Material (SB-M)", "All finish surfaces free of sharp edges, delamination, micro-cracks visible under 50-lux spot check. Gap tolerance: joints ≤ 1.5mm for premium finishes.")

S41 += heading2("41.3  Commissioning Test Procedures")
S41 += label_value("SC-TEST-01 Acoustic Walk", "Shore agent conducts 15-minute acoustic walk. Test: clap test (RT60 estimation), background noise measurement (dB meter), door/window seal verification. Tools: Decibel X app + calibrated sound level meter.")
S41 += label_value("SC-TEST-02 Lighting Scene Test", "All lighting scenes (day/evening/task) tested at design lux levels. CCT consistency verified across all fixtures. Dimmer range: 5–100% confirmed. Document: photo evidence with lux reading overlay.")
S41 += label_value("SC-TEST-03 Thermal Equilibrium Check", "HVAC operated at design setpoints for minimum 2 hours pre-test. Three-zone temperature map taken: floor (0.1m), seated (1.1m), ceiling (1.7m). Results logged in Field App.")
S41 += label_value("SC-TEST-04 Air Quality Baseline", "IAQ meter reading taken at 30 days post-installation. All readings logged. If TVOC > 500 μg/m3: mandatory ventilation flush protocol activated; re-test at 60 days.")
S41 += label_value("SC-TEST-05 Tactile Finish Survey", "100% surface inspection by Shore agent. Defects logged via Field App QC capture (src/qc-anomaly/). All critical defects (Level 2+) resolved before Sensory Commissioning Sign-Off.")

S41 += heading2("41.4  Sensory Commissioning Sign-Off Hierarchy")
S41 += label_value("Level 1 — Agent Verified", "Shore/Hana completes all SC-TEST-01 to SC-TEST-05; results within benchmark. Agent sign-off in Field App.")
S41 += label_value("Level 2 — Client Acceptance", "Client representative attends sensory walk (minimum 30 minutes). Client sign-off on SC-FORM-001.")
S41 += label_value("Level 3 — Programme Director Release", "Programme Director confirms Sensory Commissioning complete — triggers final payment milestone and moves project to POE phase (S42).")

S41 += heading2("41.5  Agent Responsibilities & GitHub Integration")
S41 += label_value("Shore (Group B)", "Leads all sensory commissioning tests; operates Field App SC-TEST suite; issues Level 1 verification")
S41 += label_value("Hana (Group B)", "Environmental monitoring (air quality, thermal); maintains IAQ baseline database; 30/60-day re-test scheduling")
S41 += label_value("Field App Integration", "SC-TEST results captured in packages/field-app/; photos via supabase/functions/field-capture/; anomalies via src/qc-anomaly/")
S41 += body("AMD-004 WS-B shall add src/sensory-commissioning/ module with: benchmark-config/, test-protocol/, sign-off-workflow/, and supabase table sensory_commissioning_records.")

S41 += heading2("41.6  S41 Milestones")
S41 += label_value("S41-M1", "SC-FORM-001 template deployed in Field App; Shore agent trained on all 5 test procedures (Q2 2031)")
S41 += label_value("S41-M2", "src/sensory-commissioning/ module operational; first project sensory commissioning completed (Q3 2031)")
S41 += label_value("S41-M3", "WELL Sound and Thermal feature compliance verified via Sensory Commissioning for WELL-target projects (Q4 2031)")
S41 += label_value("S41-M4", "Sensory Commissioning pass rate KPI established — target ≥ 90% first-attempt pass (Q1 2032)")

# ============================================================
# SECTION 42 — Pillar 6b: Post-Occupancy Evaluation (POE)
# ============================================================
S42 = ""
S42 += heading1("42. Pillar 6b — Post-Occupancy Evaluation (POE) System (GAP-04)")
S42 += heading2("42.1  Overview")
S42 += body("Section 42 establishes the Post-Occupancy Evaluation (POE) System, closing GAP-04. POE is the structured evaluation "
            "of a completed interior environment after occupancy to assess performance against design intent, client satisfaction, "
            "and WELL/LEED targets. DAPH Decor currently has src/core/telemetry/ for platform telemetry but no project-level "
            "POE survey engine, occupant satisfaction scoring, or delta analysis vs design intent. "
            "This section defines the POE schedule, evaluation framework, survey methodology, and GitHub module specification.")
S42 += body("Scope: All DAPH Decor projects with contract value ≥ THB 1.5M. POE data informs DAPH design standards library. "
            "Responsible Agents: Pulse (Analytics, Group C ≥94%), Frame (Reporting, Group C ≥94%).")

S42 += heading2("42.2  POE Schedule & Trigger Points")
S42 += label_value("POE-30: 30-Day Quick Check", "Triggered automatically 30 days after Sensory Commissioning sign-off (S41). Focus: punch list resolution, client onboarding satisfaction, critical snag follow-up. Duration: 30 minutes. Method: Field App survey + phone call.")
S42 += label_value("POE-90: 3-Month Assessment", "Trigger: 90 days post-handover. Focus: HVAC/lighting performance in real occupancy, material performance, maintenance issues. Duration: 60-minute site visit by Hana + short client survey (15 questions). Generates: POE-REPORT-90.")
S42 += label_value("POE-180: 6-Month Performance Review", "Trigger: 180 days post-handover. Focus: occupant wellbeing, biophilic pattern effectiveness, WELL feature compliance re-check, energy performance. Duration: 90-minute site visit + full occupant survey (30 questions). Generates: POE-REPORT-180 submitted to SC.")
S42 += label_value("POE-365: 12-Month Annual Evaluation", "Trigger: 365 days post-handover. Focus: material durability, seasonal performance variation, brand satisfaction, referral likelihood. Duration: full evaluation + photography update. Generates: POE-REPORT-365 — benchmark database entry.")

S42 += heading2("42.3  Evaluation Framework — 6 Domains")
S42 += label_value("Domain 1: Technical Performance", "HVAC, lighting, acoustic performance vs SB benchmarks (S41.2). Objective measurements re-taken.")
S42 += label_value("Domain 2: Occupant Wellbeing", "Self-reported comfort, stress reduction, biophilic pattern perception, nature connection score.")
S42 += label_value("Domain 3: Material & Finish Durability", "Visual inspection of all surfaces, hardware, joinery. Defect rate vs expected warranty period.")
S42 += label_value("Domain 4: Functional Satisfaction", "Space utilisation, storage adequacy, circulation flow, furniture ergonomics.")
S42 += label_value("Domain 5: WELL/LEED Compliance", "Re-verification of WELL features per S39. LEED post-occupancy credits confirmed. Biophilic pattern retention score.")
S42 += label_value("Domain 6: Client & Brand Satisfaction", "NPS score, repeat business likelihood, referral willingness, DAPH brand perception.")

S42 += heading2("42.4  POE Survey Framework")
S42 += body("Standard POE surveys are administered digitally via LINE OA or client portal (supabase/functions/customer-design-view/):")
S42 += bullet("POE-30 Survey: 8 questions — satisfaction with handover, snagging resolution, first impressions (1–5 Likert scale)")
S42 += bullet("POE-90 Survey: 15 questions — 6 technical, 5 functional, 4 satisfaction questions")
S42 += bullet("POE-180 Survey: 30 questions — all 6 domains; includes open text for testimonials; NPS measured")
S42 += bullet("POE-365 Survey: 30 questions + site photography — annual full evaluation; fed into DAPH design standards update")
S42 += body("POE survey responses are analysed by Pulse agent and reported to Frame agent for SC dashboard integration (S36 analytics extension).")

S42 += heading2("42.5  Delta Analysis — Design Intent vs Actual Performance")
S42 += body("Frame agent generates a Design Intent vs Actual Performance delta report at POE-180 and POE-365:")
S42 += label_value("DI-01 Biophilic Pattern Retention", "% of 14 patterns still perceived by occupants vs designed. Target ≥ 80% at POE-180.")
S42 += label_value("DI-02 Lighting Performance Delta", "Measured lux vs designed lux ±15% tolerance. CCT drift flagged if > 200K from commissioning baseline.")
S42 += label_value("DI-03 Acoustic Performance Delta", "RT60 and NC level vs SC-TEST-01 baseline. Furnishing changes may alter acoustics.")
S42 += label_value("DI-04 Client Satisfaction Delta", "NPS at POE-180 vs POE-30 initial satisfaction. Target: NPS ≥ +50 at POE-180.")
S42 += label_value("DI-05 Material Durability Score", "Defect rate per 100 linear metres of joinery/surface. Target ≤ 3 defects at 12 months.")

S42 += heading2("42.6  GitHub Module Specification: src/poe/")
S42 += body("AMD-004 WS-B shall commission src/poe/ module with:")
S42 += bullet("src/poe/schedule/ — automated POE trigger scheduling (30/90/180/365-day) linked to project handover date")
S42 += bullet("src/poe/survey-engine/ — digital survey builder, LINE OA distribution, response collection")
S42 += bullet("src/poe/delta-analysis/ — Design Intent vs Actual algorithm, delta report generator")
S42 += bullet("src/poe/benchmarks/ — rolling DAPH design standards database fed by POE-365 data")
S42 += bullet("supabase table poe_evaluations — stores all POE records, linked to project_id")

S42 += heading2("42.7  S42 Milestones")
S42 += label_value("S42-M1", "POE-30 quick check survey deployed via LINE OA for all active projects (Q2 2031)")
S42 += label_value("S42-M2", "src/poe/ module operational; POE-90 and POE-180 assessments running on pilot projects (Q3 2031)")
S42 += label_value("S42-M3", "First POE-365 annual evaluation completed; delta analysis submitted to SC (Q4 2031)")
S42 += label_value("S42-M4", "DAPH design standards database updated with POE benchmark data — minimum 10 project entries (Q2 2032)")

# ============================================================
# SECTION 43 — SC Governance Module & Programme Charter Registry
# ============================================================
S43 = ""
S43 += heading1("43. SC Governance Module & Programme Charter Registry (GAP-07)")
S43 += heading2("43.1  Overview")
S43 += body("Section 43 establishes the Steering Committee Governance Module and Programme Charter Registry, closing GAP-07. "
            "The SOP-GitHub Coverage Analysis confirmed that Sections S23, S28, S32, and S38 — covering SC governance, "
            "AMD programme lifecycle, decision rights, and PDD management — exist entirely in DOCX form with no corresponding "
            "code implementation. This section defines the governance data model, Supabase schema, and agent integration "
            "required to operationalise SC governance within the IIMOS Manufacturing OS.")
S43 += body("Scope: All AMD programme governance activities from AMD-004 onwards. "
            "Responsible Agents: Core (Programme Director AI, Group D ≥97%), Guardian (Governance Compliance, Group D ≥97%), Nexus (Integration, Group D ≥97%).")

S43 += heading2("43.2  Steering Committee Charter Registry v3.0")
S43 += body("The SC Charter Registry is the authoritative record of all Steering Committee decisions, resolutions, and mandate changes. "
            "It supersedes the manual DOCX-based records maintained in S23 and S34.")
S43 += label_value("Registry Record Types", "SC-RESOLUTION (numbered SC-YYYY-NN), AMD-MANDATE (programme scope decisions), POLICY-RATIFICATION (governance policy approvals), ESCALATION-RECORD (DFV-Level 3, SLA breach, P0 incidents)")
S43 += label_value("Immutability", "All SC resolutions are append-only in Supabase. No deletion or modification post-SC-signature. Audit trail maintained per ISO 9001 clause 7.5 (documented information).")
S43 += label_value("Numbering Convention", "SC-[YEAR]-[NN] — e.g. SC-2030-01 (AMD-004 ratification). Sequential within calendar year. Cross-referenced in all SOP sections citing SC decisions.")
S43 += label_value("Access Control", "SC records readable by all agents; writable only by Core and Guardian agents (Group D clearance). src/iam/ enforces role.")

S43 += heading2("43.3  Decision Rights Framework v3.0")
S43 += body("The following decision rights matrix governs AMD programme activities post-AMD-004 ratification:")
S43 += label_value("D1 — Programme Director", "Approve Gate 3 releases, authorize DFV-Level 3 CRs, ratify WELL/LEED scope changes, approve POE-365 benchmark database updates")
S43 += label_value("D2 — Steering Committee", "Ratify AMD programme amendments, approve annual programme reviews (APR), authorize new workstream commissioning, approve policy documents GV2-P1 through GV2-P5")
S43 += label_value("D3 — Design Director", "Approve Gate 0/1/2 design decisions, sign off biophilic pattern matrix (S39), validate LEED scorecard at G2")
S43 += label_value("D4 — Agent (Autonomous)", "Core/Guardian agents may autonomously approve Level 1 decisions within pre-authorised parameters: routine SLA breach notifications, POE scheduling, material vault tag updates")

S43 += heading2("43.4  AMD Programme Lifecycle State Machine")
S43 += body("Each AMD programme follows a defined lifecycle state machine, implemented in Supabase as programme_state enum:")
S43 += label_value("State: PROPOSED", "AMD programme proposed by APR review; PDD template initiated (S38 framework)")
S43 += label_value("State: RATIFIED", "SC ratification resolution issued (SC-YYYY-NN); workstreams activated")
S43 += label_value("State: IN_PROGRESS", "Workstreams WS-A through WS-E executing; quarterly SC reports generated by Core agent")
S43 += label_value("State: REVIEW", "Annual Programme Review (APR) activated; scope extension or closure decision pending")
S43 += label_value("State: COMPLETED", "All workstream milestones delivered; SC formal completion declaration issued; next AMD programme triggered")
S43 += label_value("State: SUPERSEDED", "Programme documents superseded by successor AMD; archived in Supabase with read-only access")

S43 += heading2("43.5  SC Agenda & Resolution Store — Supabase Schema")
S43 += body("AMD-004 WS-A shall create the following Supabase tables for SC governance:")
S43 += bullet("sc_resolutions (id, resolution_code, amd_programme, title, decision_text, ratified_by, ratified_at, related_sections)")
S43 += bullet("amd_programmes (id, code, name, state, ratification_sc, start_date, target_completion, workstreams JSONB)")
S43 += bullet("governance_policies (id, code, title, version, amd_programme, status, approved_at, superseded_at, doc_url)")
S43 += bullet("sc_agenda_items (id, meeting_date, item_type, title, presenter_agent, resolution_id, outcome)")
S43 += bullet("programme_milestones (id, amd_programme, workstream, milestone_code, title, target_date, status, evidence_url)")

S43 += heading2("43.6  AMD-004 Governance Activation Checklist")
S43 += label_value("GOV-AMD4-01", "Supabase sc_resolutions table created; SC-2030-01 AMD-004 ratification record inserted")
S43 += label_value("GOV-AMD4-02", "amd_programmes table created; AMD-004 record in RATIFIED state; WS-A through WS-E workstreams populated")
S43 += label_value("GOV-AMD4-03", "Core agent configured with SC governance write permissions in src/iam/")
S43 += label_value("GOV-AMD4-04", "Guardian agent automated quarterly SC report generator linked to programme_milestones table")
S43 += label_value("GOV-AMD4-05", "LINE OA SC notification channel configured for resolution alerts (supabase/functions/line-outbound-sender/)")
S43 += label_value("GOV-AMD4-06", "DOCX SOP sections S23, S28, S32, S38 cross-referenced with Supabase governance records as authoritative source")

S43 += heading2("43.7  S43 Milestones")
S43 += label_value("S43-M1", "Supabase governance schema deployed; SC-2030-01 AMD-004 record live (Q3 2030 — AMD-004 ratification)")
S43 += label_value("S43-M2", "Core and Guardian agents configured with governance write access; first automated SC quarterly report (Q4 2030)")
S43 += label_value("S43-M3", "All historical SC resolutions (SC-2025 through SC-2030) migrated from DOCX to Supabase sc_resolutions table (Q1 2031)")
S43 += label_value("S43-M4", "SC Governance Module fully operational — DOCX SOP governance sections become read-only references to Supabase system of record (Q2 2031)")

# ============================================================
# SECTION 44 — 28-Agent Governance Code Guide & Gap Resolution
# ============================================================
S44 = ""
S44 += heading1("44. 28-Agent Governance Code Implementation Guide & Unified Gap Resolution Framework (GAP-05, GAP-08)")
S44 += heading2("44.1  Overview")
S44 += body("Section 44 consolidates the technical implementation guide for the 28-Agent Governance Layer in code (GAP-05) "
            "and the AMD-004 Unified Gap Resolution Framework (GAP-08). The SOP-GitHub Coverage Analysis identified 15 gaps "
            "across three severity levels. This section provides the authoritative migration path from DOCX-governed policy "
            "to code-enforced governance, beginning with AMD-004 WS-A (Q3 2030) and completing by AMD-004 WS-E (Q2 2033).")
S44 += body("Responsible Agents: Core (Programme Director, Group D ≥97%), Nexus (Integration, Group D ≥97%), "
            "Vega (Technical Architecture, Group D ≥97%), Ledger (Audit/Compliance, Group D ≥97%).")

S44 += heading2("44.2  28-Agent SLA Group Configuration in src/workflow/sla/")
S44 += body("The 28-agent SLA Group A–D threshold table (S17) shall be migrated from DOCX to a configuration file "
            "in src/workflow/sla/agent-config.ts with the following structure:")
S44 += label_value("Group A (≥95% accuracy)", "Kelly, Signal, Aria, Blaze, Nova — real-time SLA sweep via supabase/functions/sla-sweep-scheduler/")
S44 += label_value("Group B (≥93% accuracy)", "Compass, Remy, Scout, Finn, Hana, Ember, Shore, Draft — daily SLA batch review")
S44 += label_value("Group C (≥94% accuracy)", "Atlas, Bo, Forge, Leo, Ops, Stone, Pulse, Frame — weekly SLA aggregate report")
S44 += label_value("Group D (≥97% accuracy)", "Core, Nexus, Rex, Guardian, Talent, Vega, Ledger — continuous monitoring; breach triggers immediate SC notification")
S44 += body("SLA breach thresholds shall trigger escalation via supabase/functions/notify-overdue/ with severity mapping: "
            "Group D breach → Programme Director + SC notification; Group A breach → Design Director notification; "
            "Group B/C breach → workstream lead notification.")

S44 += heading2("44.3  Per-Agent KPI Baseline Configuration")
S44 += body("Each of the 28 agents shall have a KPI baseline record in Supabase table agent_kpi_baselines with fields:")
S44 += bullet("agent_id, agent_name, sla_group, accuracy_threshold, response_time_p95_ms, tasks_per_day_target")
S44 += bullet("quality_score_min, handoff_success_rate_min, client_satisfaction_nps_min")
S44 += bullet("current_period_score, baseline_date, last_review_date, next_review_date")
S44 += body("KPI baselines are reviewed quarterly by Pulse (analytics) and Ledger (audit). "
            "Deviations of > 5% from baseline for two consecutive quarters trigger Agent Lifecycle Review (S21 protocol).")

S44 += heading2("44.4  Gap Resolution Registry — All 15 Gaps")
S44 += body("The following table summarises the complete 15-gap resolution plan by AMD-004 workstream:")
S44 += label_value("GAP-01 Biophilic/WELL  [HIGH]", "WS-A: S39 SOP published. WS-B: src/biophilic/ module built. Target: Q3 2031")
S44 += label_value("GAP-02 Design Freeze Gate  [HIGH]", "WS-A: src/gate/ extension. WS-B: full client workflow. Target: Q3 2031")
S44 += label_value("GAP-03 Sensory Commissioning  [HIGH]", "WS-B: src/sensory-commissioning/ module. Target: Q3 2031")
S44 += label_value("GAP-04 POE System  [HIGH]", "WS-B: src/poe/ module. Target: Q3 2031")
S44 += label_value("GAP-05 28-Agent Governance Code  [HIGH]", "WS-A: agent-config.ts + agent_kpi_baselines. Target: Q4 2030")
S44 += label_value("GAP-06 ISO 9001/RIBA Audit Trail  [HIGH]", "WS-C: src/workflow/audit/ extension. Target: Q2 2032")
S44 += label_value("GAP-07 SC Governance Module  [HIGH]", "WS-A: S43 + Supabase schema. Target: Q4 2030")
S44 += label_value("GAP-08 AMD-004 Programme Tracker  [HIGH]", "WS-A: amd_programmes table + Core agent. Target: Q4 2030")
S44 += label_value("GAP-09 Mock-up Approval Workflow  [MEDIUM]", "WS-B: src/workflow/approval/ extension. Target: Q1 2032")
S44 += label_value("GAP-10 Unified KPI Dashboard  [MEDIUM]", "WS-C: dashboard/ integration layer. Target: Q2 2032")
S44 += label_value("GAP-11 Emergency Escalation Protocol  [MEDIUM]", "WS-C: severity matrix + escalation chain. Target: Q2 2032")
S44 += label_value("GAP-12 Governance Amendment Tracking  [MEDIUM]", "WS-B: governance_policies table. Target: Q1 2032")
S44 += label_value("GAP-13 AI Ethics Audit Module  [LOW]", "WS-D: bias monitoring + ethical log. Target: Q3 2032")
S44 += label_value("GAP-14 Agent Decommissioning Workflow  [LOW]", "WS-D: lifecycle retire state. Target: Q3 2032")
S44 += label_value("GAP-15 PDPA DSAR Workflow  [LOW]", "WS-D: src/iam/ DSAR extension. Target: Q4 2032")

S44 += heading2("44.5  AMD-004 Unified Gap Resolution Roadmap")
S44 += label_value("Phase 1 — WS-A (Q3–Q4 2030)", "Bridge DOCX → Code: GAP-05 (SLA config), GAP-07 (SC governance schema), GAP-08 (AMD tracker), GAP-02 initial (Gate scaffolding)")
S44 += label_value("Phase 2 — WS-B (FY2031)", "New module development: GAP-01 (biophilic), GAP-03 (sensory), GAP-04 (POE), GAP-02 complete (Gate workflow), GAP-09 (mock-up), GAP-12 (amendment tracking)")
S44 += label_value("Phase 3 — WS-C/D (FY2032)", "Integration & compliance: GAP-06 (ISO 9001 audit), GAP-10 (unified dashboard), GAP-11 (emergency protocol), GAP-13/14/15 (ethics, decommission, PDPA)")
S44 += label_value("Phase 4 — WS-E (Q1–Q2 2033)", "Validation, stress testing, and World-Class certification against RIBA POW + WELL + ISO 9001. Target: 0 HIGH gaps remaining.")

S44 += heading2("44.6  S44 Milestones")
S44 += label_value("S44-M1", "agent-config.ts with 28-agent SLA Group configuration committed to monolith-workspace main branch (Q3 2030)")
S44 += label_value("S44-M2", "Supabase agent_kpi_baselines table populated; KPI baseline review cycle active (Q4 2030)")
S44 += label_value("S44-M3", "All 8 HIGH severity gaps resolved — verified by Gap Resolution Registry audit (Q4 2031)")
S44 += label_value("S44-M4", "All 15 gaps resolved — DAPH Decor World-Class Framework certification audit submitted to SC (Q2 2033)")
S44 += label_value("S44-M5", "S39–S44 accepted and merged into monolith_project_summary_v3.0 as AMD-004 foundations (Q3 2030)")

# ============================================================
# Combine all sections
# ============================================================
NEW_XML = S39 + S40 + S41 + S42 + S43 + S44

# Insert before </w:body>
if '</w:body>' not in xml:
    print('ERROR: </w:body> not found')
    exit(1)

new_xml = xml.replace('</w:body>', NEW_XML + '</w:body>', 1)

# Count w:ins in new content
ins_count = len(re.findall(r'<w:ins[ >]', NEW_XML))
print(f'New w:ins inserted: {ins_count}')
print(f'IDs used: 10 to {_id-1}')
print(f'New XML length: {len(new_xml):,} chars')

# Write back
all_files['word/document.xml'] = new_xml.encode('utf-8')

out = SRC
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as zout:
    for name, data in all_files.items():
        zout.writestr(name, data)

# Verify
with zipfile.ZipFile(out, 'r') as z2:
    xml2 = z2.read('word/document.xml').decode('utf-8')
    ins_total = len(re.findall(r'<w:ins[ >]', xml2))
    print(f'VERIFY — total w:ins in doc: {ins_total}')
    print(f'File size: {os.path.getsize(out):,} bytes')
    # Spot check section headings
    for snum in ['39.', '40.', '41.', '42.', '43.', '44.']:
        present = f'{snum} Pillar' in xml2 or f'{snum} AMD' in xml2 or f'{snum} SC' in xml2 or f'{snum} 28-Agent' in xml2
        ok = '39.' in xml2 and '40.' in xml2 and '41.' in xml2 and '42.' in xml2 and '43.' in xml2 and '44.' in xml2
    s39_ok = '39. Pillar 1' in xml2
    s40_ok = '40. Pillar 2' in xml2
    s41_ok = '41. Pillar 6a' in xml2
    s42_ok = '42. Pillar 6b' in xml2
    s43_ok = '43. SC Governance' in xml2
    s44_ok = '44. 28-Agent' in xml2
    print(f'S39:{s39_ok} S40:{s40_ok} S41:{s41_ok} S42:{s42_ok} S43:{s43_ok} S44:{s44_ok}')
    if all([s39_ok, s40_ok, s41_ok, s42_ok, s43_ok, s44_ok]):
        print('PASS — S39–S44 all present')
    else:
        print('FAIL — missing sections')
