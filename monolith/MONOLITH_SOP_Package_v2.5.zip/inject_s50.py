"""
inject_s50.py
Inject Section S50 into monolith_project_summary_v25_accepted.docx
S50: Phase 2 Programme Definition Document (PDD)
    50.1 Overview  |  50.2 SC Resolution SC-2032-XX
    50.3 GAP-05/06/09/10/11/12 Workplan  |  50.4 Budget Estimate
    50.5 Milestones P2-M1–P2-M4  |  50.6 Governance  |  50.7 Readiness Checklist
IDs start at 1257 (continuing from inject_s48_s49.py which used 959–1256)
"""
import zipfile, re, shutil, os

SRC = '/home/sandbox/monolith_project_summary_v25_accepted.docx'
DST = '/home/sandbox/monolith_project_summary_v25_accepted.docx'
BAK = '/home/sandbox/monolith_project_summary_v25_accepted_pre_s50_backup.docx'

shutil.copy(SRC, BAK)
print(f'Backup: {BAK}')

with zipfile.ZipFile(SRC, 'r') as z:
    xml = z.read('word/document.xml').decode('utf-8')
    all_files = {name: z.read(name) for name in z.namelist()}

_id = 1257

def nid():
    global _id
    v = _id
    _id += 1
    return v

AUTHOR = "Scispace Agent"
DATE   = "2026-09-03T00:00:00Z"

def heading1(text):
    pi, ri = nid(), nid()
    return (
        f'<w:p><w:pPr><w:spacing w:before="320" w:after="100"/>'
        f'<w:rPr><w:ins w:id="{pi}" w:author="{AUTHOR}" w:date="{DATE}"/></w:rPr></w:pPr>'
        f'<w:ins w:id="{ri}" w:author="{AUTHOR}" w:date="{DATE}">'
        f'<w:r><w:rPr><w:b/><w:bCs/><w:sz w:val="36"/><w:szCs w:val="36"/>'
        f'<w:color w:val="1f2d5a"/></w:rPr>'
        f'<w:t xml:space="preserve">{text}</w:t></w:r></w:ins></w:p>\n'
    )

def heading2(text):
    pi, ri = nid(), nid()
    return (
        f'<w:p><w:pPr><w:spacing w:before="200" w:after="80"/>'
        f'<w:rPr><w:ins w:id="{pi}" w:author="{AUTHOR}" w:date="{DATE}"/></w:rPr></w:pPr>'
        f'<w:ins w:id="{ri}" w:author="{AUTHOR}" w:date="{DATE}">'
        f'<w:r><w:rPr><w:b/><w:bCs/><w:sz w:val="28"/><w:szCs w:val="28"/>'
        f'<w:color w:val="2e75b6"/></w:rPr>'
        f'<w:t xml:space="preserve">{text}</w:t></w:r></w:ins></w:p>\n'
    )

def body(text, indent=400):
    pi, ri = nid(), nid()
    return (
        f'<w:p><w:pPr><w:spacing w:before="0" w:after="80"/>'
        f'<w:ind w:left="{indent}"/>'
        f'<w:rPr><w:ins w:id="{pi}" w:author="{AUTHOR}" w:date="{DATE}"/></w:rPr></w:pPr>'
        f'<w:ins w:id="{ri}" w:author="{AUTHOR}" w:date="{DATE}">'
        f'<w:r><w:rPr><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>'
        f'<w:t xml:space="preserve">{text}</w:t></w:r></w:ins></w:p>\n'
    )

def bullet(text):
    pi, ri = nid(), nid()
    return (
        f'<w:p><w:pPr><w:spacing w:before="0" w:after="60"/>'
        f'<w:ind w:left="600" w:hanging="200"/>'
        f'<w:rPr><w:ins w:id="{pi}" w:author="{AUTHOR}" w:date="{DATE}"/></w:rPr></w:pPr>'
        f'<w:ins w:id="{ri}" w:author="{AUTHOR}" w:date="{DATE}">'
        f'<w:r><w:rPr><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr>'
        f'<w:t xml:space="preserve">&#x2022; {text}</w:t></w:r></w:ins></w:p>\n'
    )

def label_value(label, value):
    pi, r1, r2 = nid(), nid(), nid()
    return (
        f'<w:p><w:pPr><w:spacing w:before="0" w:after="60"/>'
        f'<w:ind w:left="600"/>'
        f'<w:rPr><w:ins w:id="{pi}" w:author="{AUTHOR}" w:date="{DATE}"/></w:rPr></w:pPr>'
        f'<w:ins w:id="{r1}" w:author="{AUTHOR}" w:date="{DATE}">'
        f'<w:r><w:rPr><w:b/><w:bCs/><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr>'
        f'<w:t xml:space="preserve">{label}:  </w:t></w:r></w:ins>'
        f'<w:ins w:id="{r2}" w:author="{AUTHOR}" w:date="{DATE}">'
        f'<w:r><w:rPr><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr>'
        f'<w:t xml:space="preserve">{value}</w:t></w:r></w:ins></w:p>\n'
    )

# ============================================================
# SECTION 50 — Phase 2 Programme Definition Document (PDD)
# ============================================================
S50 = ""
S50 += heading1("Section 50 — Phase 2 Programme Definition Document (PDD)")
S50 += body(
    "Section 50 establishes the Programme Definition Document (PDD) for Phase 2 of the "
    "MONOLITH DAPH Decor AI Agent Programme. Phase 2 targets coverage improvement from 68% "
    "to 80% by closing GAP-05, GAP-06, GAP-09, GAP-10, GAP-11, and GAP-12, authorised under "
    "SC Resolution SC-2032-XX. Total Phase 2 budget estimate: THB 6.0M, delivery target Q4 2033."
)

S50 += heading2("50.1  ภาพรวม Phase 2 PDD (Phase 2 Overview)")
S50 += body(
    "Phase 2 ของโครงการ MONOLITH DAPH Decor AI Agent Programme มีวัตถุประสงค์เพื่อเพิ่มความครอบคลุม "
    "ของ SOP จาก 68% (ผลสำเร็จ Phase 1) ไปเป็น 80% โดยการปิด 6 Gap ลำดับต่อไปจากทะเบียน Gap 15 ข้อ "
    "ได้แก่ GAP-05 (AI Creative Engine), GAP-06 (Cross-Pillar Event Bus), GAP-09 (Material Intelligence), "
    "GAP-10 (Contractor/Vendor Integration), GAP-11 (Spatial Analytics), และ GAP-12 (Multi-language Support)"
)
S50 += label_value("Coverage target", "68% (Phase 1 achieved) → 80% (Phase 2 target)")
S50 += label_value("Authorisation", "SC Resolution SC-2032-XX (Q3 2032)")
S50 += label_value("Budget estimate", "THB 6.0M (includes 10% contingency)")
S50 += label_value("Timeline", "Q1 2033 – Q4 2033 (4 quarters)")
S50 += label_value("Gaps addressed", "GAP-05, GAP-06, GAP-09, GAP-10, GAP-11, GAP-12")
S50 += label_value("Programme Director", "To be nominated by SC post-resolution")
S50 += label_value("SOP sections created", "S50 (this PDD) + planned implementation sections S51–S56")

S50 += heading2("50.2  SC Resolution SC-2032-XX")
S50 += body(
    "SC Resolution SC-2032-XX อนุมัติการเริ่มต้น Phase 2 ของโครงการ MONOLITH DAPH Decor AI Agent "
    "Programme ต่อจากการปิด Phase 1 อย่างเป็นทางการ โดยมีเงื่อนไขว่า Phase 1 Completion Certificate "
    "ได้รับการรับรองจากคณะกรรมการกำกับดูแล และ AMD-004 ทั้ง 5 Workstream ส่งมอบผลลัพธ์ครบถ้วน"
)
S50 += label_value("Resolution reference", "SC-2032-XX")
S50 += label_value("Issuing body", "MONOLITH DAPH Steering Committee (SC)")
S50 += label_value("Resolution date", "Q3 2032 (target)")
S50 += label_value("Pre-conditions",
    "Phase 1 gate passed: GAP-01/02/03/04/07/08 closed; AMD-004 AMD4-CLOSE-01–05 completed; "
    "Coverage 68% independently verified; SC-2030-01 Phase 1 obligations discharged")
S50 += label_value("Phase 2 mandate",
    "Authorise THB 6.0M Phase 2 budget; nominate Phase 2 Programme Director; "
    "approve GAP-05/06/09/10/11/12 workplan; set coverage milestone 80% by Q4 2033")
S50 += label_value("Reporting cycle", "Quarterly SC reporting; milestone gate at 75% coverage midpoint")
S50 += label_value("Phase 3 pre-condition", "SC-2033-XX gate review upon Phase 2 completion")

S50 += heading2("50.3  GAP-05 / GAP-06 / GAP-09 / GAP-10 / GAP-11 / GAP-12 Workplan")
S50 += body(
    "50.3.1  GAP-05: AI Creative Engine & Generative Design Workflow — High Priority"
)
S50 += label_value("Owner agent", "Aria (Group A, SLA ≥95%) + Nova (Group A, ≥95%)")
S50 += label_value("Budget", "THB 1.5M")
S50 += label_value("Timeline", "Q1–Q3 2033")
S50 += label_value("Deliverables",
    "src/creative-engine/ AI generative design module; style-transfer pipeline; "
    "Pillar 5 Creative Direction SOP S51; integration with Atlas (Group C) spatial context")
S50 += label_value("Success criteria",
    "AI-assisted concept generation operational; 80% designer adoption rate; "
    "creative review cycle reduced 40%; GAP-05 formally closed")

S50 += body("50.3.2  GAP-06: Cross-Pillar Event Bus & Real-time Integration — High Priority")
S50 += label_value("Owner agent", "Signal (Group A, SLA ≥95%) + Core (Group D, ≥97%)")
S50 += label_value("Budget", "THB 1.0M")
S50 += label_value("Timeline", "Q1–Q2 2033")
S50 += label_value("Deliverables",
    "src/event-bus/ message broker; cross-pillar event schema; "
    "Pub/Sub integration with Supabase; SOP S52 Event Bus Governance; "
    "audit trail EVENT-001–010")
S50 += label_value("Success criteria",
    "Real-time event propagation across all 6 Pillars; sub-100ms event latency; "
    "zero data loss in event replay; GAP-06 formally closed")

S50 += body("50.3.3  GAP-09: Material Intelligence & Procurement Integration — Medium Priority")
S50 += label_value("Owner agent", "Forge (Group C, SLA ≥94%) + Remy (Group B, ≥93%)")
S50 += label_value("Budget", "THB 0.8M")
S50 += label_value("Timeline", "Q2–Q3 2033")
S50 += label_value("Deliverables",
    "src/material-intelligence/ module; supplier API integrations; material carbon-footprint scoring; "
    "SOP S53 Material Intelligence; procurement workflow MAT-001–020")
S50 += label_value("Success criteria",
    "Material specification auto-matched to approved supplier catalogue; "
    "procurement lead time reduced 30%; sustainability score integrated; GAP-09 closed")

S50 += body("50.3.4  GAP-10: Contractor & Vendor Management Integration — Medium Priority")
S50 += label_value("Owner agent", "Ledger (Group D, SLA ≥97%) + Compass (Group B, ≥93%)")
S50 += label_value("Budget", "THB 0.7M")
S50 += label_value("Timeline", "Q2–Q4 2033")
S50 += label_value("Deliverables",
    "src/vendor/ contractor management module; contract lifecycle CNTR-001–050; "
    "SOP S54 Contractor & Vendor; Supabase vendor registry schema; "
    "performance scorecard integration with KPI-001–024")
S50 += label_value("Success criteria",
    "All contractor engagements tracked in system; payment milestone automation; "
    "vendor SLA compliance rate ≥90%; GAP-10 closed")

S50 += body("50.3.5  GAP-11: Spatial Analytics & Occupancy Intelligence — Medium Priority")
S50 += label_value("Owner agent", "Atlas (Group C, SLA ≥94%) + Bo (Group C, ≥94%)")
S50 += label_value("Budget", "THB 0.8M")
S50 += label_value("Timeline", "Q3–Q4 2033")
S50 += label_value("Deliverables",
    "src/spatial-analytics/ occupancy and space utilisation module; "
    "BIM integration layer; Pillar 6 spatial performance SOP S55; "
    "SPACE-001–015 analytics framework")
S50 += label_value("Success criteria",
    "Real-time space utilisation dashboard; post-occupancy spatial score baseline set; "
    "Pillar 6 coverage gap addressed; GAP-11 closed")

S50 += body("50.3.6  GAP-12: Multi-language & Localisation Support — Medium Priority")
S50 += label_value("Owner agent", "Hana (Group B, SLA ≥93%) + Ember (Group B, ≥93%)")
S50 += label_value("Budget", "THB 0.6M")
S50 += label_value("Timeline", "Q3–Q4 2033")
S50 += label_value("Deliverables",
    "src/localisation/ multi-language engine (Thai/English/Chinese baseline); "
    "SOP S56 Localisation & Language Policy; LANG-001–010 language packs; "
    "translation memory integration")
S50 += label_value("Success criteria",
    "All client-facing outputs available in Thai and English; translation accuracy ≥95%; "
    "language switch latency ≤500ms; GAP-12 closed")

S50 += heading2("50.4  Phase 2 Budget Estimate")
S50 += body(
    "ประมาณการงบประมาณ Phase 2 รวมทั้งสิ้น THB 6.0M แบ่งตาม Gap ที่จะปิด "
    "และรวมค่าสำรองฉุกเฉิน 10% (contingency THB 0.6M) สำหรับความเสี่ยงที่ไม่คาดฝัน"
)
S50 += label_value("GAP-05 AI Creative Engine", "THB 1.5M")
S50 += label_value("GAP-06 Cross-Pillar Event Bus", "THB 1.0M")
S50 += label_value("GAP-09 Material Intelligence", "THB 0.8M")
S50 += label_value("GAP-10 Contractor/Vendor", "THB 0.7M")
S50 += label_value("GAP-11 Spatial Analytics", "THB 0.8M")
S50 += label_value("GAP-12 Multi-language", "THB 0.6M")
S50 += label_value("Contingency (10%)", "THB 0.6M")
S50 += label_value("Total Phase 2 estimate", "THB 6.0M")
S50 += label_value("Approval required from", "SC Resolution SC-2032-XX")
S50 += label_value("Budget release schedule",
    "Q1 2033: THB 2.5M (GAP-05+GAP-06); "
    "Q2 2033: THB 1.5M (GAP-09+GAP-10); "
    "Q3–Q4 2033: THB 2.0M (GAP-11+GAP-12+contingency)")

S50 += heading2("50.5  Phase 2 Milestones P2-M1 through P2-M4")
S50 += body(
    "Phase 2 ดำเนินการผ่าน 4 milestones หลัก ครอบคลุม 4 ไตรมาส (Q1–Q4 2033) "
    "แต่ละ milestone มีเงื่อนไข gate review ก่อนปลดล็อคงบประมาณของ milestone ถัดไป"
)
S50 += label_value("P2-M1 (Q1 2033)",
    "Phase 2 Kickoff — SC-2032-XX ratified; Programme Director appointed; "
    "GAP-05 and GAP-06 workstreams commenced; onboarding complete; "
    "src/creative-engine/ and src/event-bus/ repositories initialised")
S50 += label_value("P2-M2 (Q2 2033)",
    "Mid-phase gate — GAP-06 Event Bus MVP delivered and tested; "
    "GAP-09 Material Intelligence build commenced; GAP-10 Contractor module design approved; "
    "coverage spot-check ≥70% confirmed; Q2 SC quarterly report submitted")
S50 += label_value("P2-M3 (Q3 2033)",
    "75% coverage gate — GAP-05 AI Creative Engine delivered; "
    "GAP-09 and GAP-10 modules UAT passed; GAP-11 Spatial Analytics commenced; "
    "GAP-12 Localisation build commenced; coverage independently verified at ≥75%")
S50 += label_value("P2-M4 (Q4 2033)",
    "Phase 2 Completion — GAP-11 Spatial Analytics and GAP-12 Localisation delivered; "
    "all 6 Phase 2 gaps formally closed (GAP-05/06/09/10/11/12); "
    "Coverage 80% verified; Phase 2 Completion Certificate issued; "
    "Phase 3 gate review initiated (SC-2033-XX)")

S50 += heading2("50.6  Programme Governance (Phase 2)")
S50 += body(
    "การกำกับดูแลโครงการ Phase 2 อยู่ภายใต้โครงสร้าง SC Oversight เดิมที่สืบเนื่องจาก AMD-004 "
    "โดยมี Programme Director คนใหม่ที่ SC แต่งตั้งรับผิดชอบการดำเนินงานประจำวัน "
    "และรายงานต่อ SC ทุกไตรมาส"
)
S50 += label_value("Steering Committee (SC)", "Oversight authority; approves gate releases; resolves escalations")
S50 += label_value("Phase 2 Programme Director",
    "Day-to-day programme leadership; P2-M1–P2-M4 milestone accountability; "
    "budget owner; nominated by SC via SC-2032-XX")
S50 += label_value("Agent owners",
    "Per-gap owner agents as defined in Section 50.3 (Aria, Signal, Forge, Ledger, Atlas, Hana)")
S50 += label_value("Governance agent — Nexus", "Group D, SLA ≥97% — Governance registry and compliance tracking")
S50 += label_value("Governance agent — Guardian", "Group D, SLA ≥97% — Risk and escalation management")
S50 += label_value("Governance agent — Vega", "Group D, SLA ≥97% — Financial controls and budget monitoring")
S50 += label_value("Reporting cadence",
    "Monthly progress report to Programme Director; quarterly SC report with gate status; "
    "ad-hoc escalation for P0/P1 risks via Guardian")
S50 += label_value("Change control",
    "Scope changes require SC written approval; budget variances >5% require SC notification; "
    "variances >15% require SC resolution amendment")

S50 += heading2("50.7  Phase 2 Readiness Checklist")
S50 += body(
    "รายการตรวจสอบความพร้อมของโครงการก่อนเริ่ม Phase 2 อย่างเป็นทางการ "
    "รายการทั้งหมดต้องได้รับการยืนยันโดย Programme Director และ SC ก่อนเบิกจ่ายงบประมาณ Q1 2033"
)
S50 += bullet("P1-CHK-01: Phase 1 Completion Certificate acknowledged and filed — AMD4-CLOSE-01 executed")
S50 += bullet("P1-CHK-02: SC-2032-XX resolution formally passed and minuted")
S50 += bullet("P1-CHK-03: Phase 2 Programme Director nominated and onboarded")
S50 += bullet("P1-CHK-04: THB 6.0M Phase 2 budget released by finance — tranches per P2-M1 schedule")
S50 += bullet("P1-CHK-05: GAP-05 and GAP-06 workstream leads confirmed (Aria, Signal team)")
S50 += bullet("P1-CHK-06: GAP-09 and GAP-10 workstream leads confirmed (Forge, Ledger team)")
S50 += bullet("P1-CHK-07: GAP-11 and GAP-12 workstream leads confirmed (Atlas, Hana team)")
S50 += bullet("P1-CHK-08: Phase 2 governance structure established — Nexus registry initialised")
S50 += bullet("P1-CHK-09: Phase 2 risk register opened — Guardian agent active P2 risk monitoring")
S50 += bullet("P1-CHK-10: src/ repository branches prepared for Phase 2 modules (creative-engine, event-bus, material-intelligence, vendor, spatial-analytics, localisation)")
S50 += bullet("P1-CHK-11: Supabase schema updated with Phase 2 table definitions")
S50 += bullet("P1-CHK-12: Coverage baseline 68% independently verified before Phase 2 commencement")
S50 += label_value("Readiness gate authority", "Phase 2 Programme Director + SC Chair co-sign")
S50 += label_value("Target readiness date", "Q3 2032 (within 4 weeks of SC-2032-XX passage)")

# ============================================================
# ASSEMBLE & INJECT
# ============================================================
NEW_CONTENT = S50

if '</w:body>' in xml:
    xml = xml.replace('</w:body>', NEW_CONTENT + '</w:body>', 1)
    print("Injection point: </w:body>")
else:
    raise ValueError("Cannot find </w:body> in document XML")

all_files['word/document.xml'] = xml.encode('utf-8')

with zipfile.ZipFile(DST, 'w', compression=zipfile.ZIP_DEFLATED) as zout:
    for name, data in all_files.items():
        zout.writestr(name, data)

# Verify
with zipfile.ZipFile(DST, 'r') as z:
    vxml = z.read('word/document.xml').decode('utf-8')
    ins_tags = re.findall(r'<w:ins[ >]', vxml)
    all_ids = re.findall(r'w:id="(\d+)"', vxml)
    s50_ok = 'SC-2032-XX' in vxml and 'P1-CHK-12' in vxml and 'GAP-05 AI Creative Engine' in vxml
    inside_h = len(re.findall(r'<w:insideH', vxml))
    inside_v = len(re.findall(r'<w:insideV', vxml))

print(f"\n=== INJECTION RESULTS ===")
print(f"w:ins tracked insertions: {len(ins_tags)}")
print(f"Max ID used: {max(int(x) for x in all_ids) if all_ids else 0}")
print(f"w:insideH intact: {inside_h}")
print(f"w:insideV intact: {inside_v}")
print(f"S50 (Phase 2 PDD) present: {s50_ok}")
print(f"File size: {os.path.getsize(DST):,} bytes")
print(f"IDs used: 1257 – {_id - 1} (total {_id - 1257} IDs allocated)")
